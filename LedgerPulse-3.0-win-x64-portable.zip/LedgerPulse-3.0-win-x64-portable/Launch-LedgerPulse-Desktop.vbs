Set WshShell = CreateObject("WScript.Shell")
strPath = Left(WScript.ScriptFullName, InStrRev(WScript.ScriptFullName, "\"))
WshShell.CurrentDirectory = strPath
WshShell.Run "cmd /c node scripts\dev-server.mjs", 0, False
WScript.Sleep 900
On Error Resume Next
WshShell.Run "msedge --app=http://127.0.0.1:5173", 1, False
If Err.Number <> 0 Then
  Err.Clear
  WshShell.Run "http://127.0.0.1:5173", 1, False
End If
