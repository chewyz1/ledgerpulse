@echo off
title LedgerPulse - Budget Tracking System
cd /d "%~dp0"
set PORT=5173
echo Starting LedgerPulse SQLite Engine on http://127.0.0.1:%PORT% ...
start "LedgerPulse Server" /min node scripts\dev-server.mjs
timeout /t 1 /nobreak >nul
start msedge --app=http://127.0.0.1:%PORT% 2>nul || start chrome --app=http://127.0.0.1:%PORT% 2>nul || start http://127.0.0.1:%PORT%
