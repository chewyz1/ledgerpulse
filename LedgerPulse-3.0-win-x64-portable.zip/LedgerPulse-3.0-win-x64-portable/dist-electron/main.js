"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const electron_1 = require("electron");
const node_path_1 = __importDefault(require("node:path"));
const db_1 = require("./db");
let mainWindow = null;
let db = null;
function getDb() {
    if (!db) {
        const dbPath = node_path_1.default.join(electron_1.app.getPath('userData'), 'budget-tracker.sqlite');
        db = new db_1.BudgetDatabase(dbPath);
        db.processDueRecurringRules();
    }
    return db;
}
function registerIpcHandlers() {
    electron_1.ipcMain.handle('budget:getProfiles', () => {
        return getDb().getProfiles();
    });
    electron_1.ipcMain.handle('budget:getProfilesOverview', (_event, month) => {
        return getDb().getProfilesOverview(month);
    });
    electron_1.ipcMain.handle('budget:createProfile', (_event, input) => {
        return getDb().createProfile(input);
    });
    electron_1.ipcMain.handle('budget:updateProfile', (_event, input) => {
        return getDb().updateProfile(input);
    });
    electron_1.ipcMain.handle('budget:deleteProfile', (_event, id) => {
        return getDb().deleteProfile(id);
    });
    electron_1.ipcMain.handle('budget:transferBetweenProfiles', (_event, input) => {
        return getDb().transferBetweenProfiles(input);
    });
    electron_1.ipcMain.handle('budget:getDashboardSummary', (_event, month, profileId) => {
        return getDb().getDashboardSummary(month, profileId);
    });
    electron_1.ipcMain.handle('budget:getCategories', (_event, profileId) => {
        return getDb().getCategories(profileId);
    });
    electron_1.ipcMain.handle('budget:createCategory', (_event, input) => {
        return getDb().createCategory(input);
    });
    electron_1.ipcMain.handle('budget:updateCategoryBudget', (_event, input) => {
        return getDb().updateCategoryBudget(input);
    });
    electron_1.ipcMain.handle('budget:deleteCategory', (_event, id) => {
        return getDb().deleteCategory(id);
    });
    electron_1.ipcMain.handle('budget:getTransactions', (_event, filters) => {
        return getDb().getTransactions(filters);
    });
    electron_1.ipcMain.handle('budget:createTransaction', (_event, input) => {
        return getDb().createTransaction(input);
    });
    electron_1.ipcMain.handle('budget:updateTransaction', (_event, input) => {
        return getDb().updateTransaction(input);
    });
    electron_1.ipcMain.handle('budget:deleteTransaction', (_event, id) => {
        return getDb().deleteTransaction(id);
    });
    electron_1.ipcMain.handle('budget:getRecurringRules', (_event, profileId) => {
        return getDb().getRecurringRules(profileId);
    });
    electron_1.ipcMain.handle('budget:createRecurringRule', (_event, input) => {
        return getDb().createRecurringRule(input);
    });
    electron_1.ipcMain.handle('budget:toggleRecurringRule', (_event, id, active) => {
        return getDb().toggleRecurringRule(id, active);
    });
    electron_1.ipcMain.handle('budget:triggerRecurringRuleNow', (_event, id, dateOverride) => {
        return getDb().triggerRecurringRuleNow(id, dateOverride);
    });
    electron_1.ipcMain.handle('budget:deleteRecurringRule', (_event, id) => {
        return getDb().deleteRecurringRule(id);
    });
    electron_1.ipcMain.handle('budget:processDueRecurringRules', (_event, todayDate) => {
        return getDb().processDueRecurringRules(todayDate);
    });
    electron_1.ipcMain.handle('budget:parseReceipt', (_event, rawText, profileId) => {
        return getDb().parseReceipt(rawText, profileId);
    });
    electron_1.ipcMain.handle('budget:exportBackupBundle', () => {
        return getDb().exportBackupBundle();
    });
    electron_1.ipcMain.handle('budget:importBackupBundle', (_event, bundle) => {
        return getDb().importBackupBundle(bundle);
    });
    electron_1.ipcMain.handle('budget:exportTransactionsCsv', (_event, options) => {
        return getDb().exportTransactionsCsv(options);
    });
    electron_1.ipcMain.handle('budget:resetDemoData', () => {
        return getDb().resetDemoData();
    });
    electron_1.ipcMain.handle('budget:getMiscLists', (_event, profileId) => {
        return getDb().getMiscLists(profileId);
    });
    electron_1.ipcMain.handle('budget:createMiscList', (_event, input) => {
        return getDb().createMiscList(input);
    });
    electron_1.ipcMain.handle('budget:deleteMiscList', (_event, id) => {
        return getDb().deleteMiscList(id);
    });
    electron_1.ipcMain.handle('budget:addMiscListItem', (_event, input) => {
        return getDb().addMiscListItem(input);
    });
    electron_1.ipcMain.handle('budget:updateMiscListItem', (_event, input) => {
        return getDb().updateMiscListItem(input);
    });
    electron_1.ipcMain.handle('budget:deleteMiscListItem', (_event, id) => {
        return getDb().deleteMiscListItem(id);
    });
    electron_1.ipcMain.handle('budget:checkoutMiscListToTransaction', (_event, input) => {
        return getDb().checkoutMiscListToTransaction(input);
    });
    electron_1.ipcMain.handle('budget:registerUserAccount', (_event, input) => {
        return getDb().registerUserAccount(input);
    });
    electron_1.ipcMain.handle('budget:loginUserAccount', (_event, input) => {
        return getDb().loginUserAccount(input);
    });
    electron_1.ipcMain.handle('budget:claimUnownedRecordsForUser', (_event, userId) => {
        return getDb().claimUnownedRecordsForUser(userId);
    });
    electron_1.ipcMain.handle('budget:getSyncChangeset', (_event, userId, sinceUtc) => {
        return getDb().getSyncChangeset(userId, sinceUtc);
    });
    electron_1.ipcMain.handle('budget:applyRemoteChangeset', (_event, changeset, userId) => {
        return getDb().applyRemoteChangeset(changeset, userId);
    });
}
function createWindow() {
    mainWindow = new electron_1.BrowserWindow({
        width: 1280,
        height: 840,
        minWidth: 960,
        minHeight: 640,
        title: 'LedgerPulse — Desktop Budget Tracker',
        backgroundColor: '#020617',
        webPreferences: {
            preload: node_path_1.default.join(__dirname, 'preload.js'),
            contextIsolation: true,
            nodeIntegration: false,
        },
    });
    const devUrl = process.env.VITE_DEV_SERVER_URL || 'http://localhost:5173';
    const isDev = !electron_1.app.isPackaged && process.env.NODE_ENV !== 'production';
    if (isDev) {
        mainWindow.loadURL(devUrl).catch(() => {
            mainWindow?.loadFile(node_path_1.default.join(__dirname, '../dist/index.html'));
        });
    }
    else {
        mainWindow.loadFile(node_path_1.default.join(__dirname, '../dist/index.html'));
    }
    mainWindow.on('closed', () => {
        mainWindow = null;
    });
}
electron_1.app.whenReady().then(() => {
    registerIpcHandlers();
    createWindow();
    electron_1.app.on('activate', () => {
        if (electron_1.BrowserWindow.getAllWindows().length === 0) {
            createWindow();
        }
    });
});
electron_1.app.on('window-all-closed', () => {
    if (process.platform !== 'darwin') {
        db?.close();
        electron_1.app.quit();
    }
});
