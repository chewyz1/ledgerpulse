"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.BudgetDatabase = void 0;
exports.deterministicUuid = deterministicUuid;
exports.advanceDateByFrequency = advanceDateByFrequency;
exports.getPreviousMonths = getPreviousMonths;
exports.formatMonthShort = formatMonthShort;
exports.getTemplateCategoriesForProfileType = getTemplateCategoriesForProfileType;
const node_sqlite_1 = require("node:sqlite");
const node_path_1 = __importDefault(require("node:path"));
const node_fs_1 = __importDefault(require("node:fs"));
const node_crypto_1 = __importDefault(require("node:crypto"));
const receiptParser_1 = require("./receiptParser");
function deterministicUuid(seed) {
    const fullSeed = `ledgerpulse-v3:${seed}`;
    let h1 = 0xdeadbeef ^ fullSeed.length;
    let h2 = 0x41c6ce57 ^ fullSeed.length;
    let h3 = 0x1b873593 ^ fullSeed.length;
    let h4 = 0x85ebca6b ^ fullSeed.length;
    for (let i = 0; i < fullSeed.length; i++) {
        const ch = fullSeed.charCodeAt(i);
        h1 = Math.imul(h1 ^ ch, 2654435761);
        h2 = Math.imul(h2 ^ ch, 1597334677);
        h3 = Math.imul(h3 ^ ch, 2246822507);
        h4 = Math.imul(h4 ^ ch, 3266489909);
    }
    h1 = Math.imul(h1 ^ (h1 >>> 16), 2246822507) ^ Math.imul(h2 ^ (h2 >>> 13), 3266489909);
    h2 = Math.imul(h2 ^ (h2 >>> 16), 2246822507) ^ Math.imul(h3 ^ (h3 >>> 13), 3266489909);
    h3 = Math.imul(h3 ^ (h3 >>> 16), 2246822507) ^ Math.imul(h4 ^ (h4 >>> 13), 3266489909);
    h4 = Math.imul(h4 ^ (h4 >>> 16), 2246822507) ^ Math.imul(h1 ^ (h1 >>> 13), 3266489909);
    const hex = (h1 >>> 0).toString(16).padStart(8, '0') +
        (h2 >>> 0).toString(16).padStart(8, '0') +
        (h3 >>> 0).toString(16).padStart(8, '0') +
        (h4 >>> 0).toString(16).padStart(8, '0');
    return [
        hex.slice(0, 8),
        hex.slice(8, 12),
        '4' + hex.slice(13, 16),
        'a' + hex.slice(17, 20),
        hex.slice(20, 32),
    ].join('-');
}
function advanceDateByFrequency(dateStr, frequency) {
    const [y, m, d] = dateStr.split('-').map(Number);
    const dt = new Date(Date.UTC(y, m - 1, d));
    if (frequency === 'weekly') {
        dt.setUTCDate(dt.getUTCDate() + 7);
    }
    else if (frequency === 'biweekly') {
        dt.setUTCDate(dt.getUTCDate() + 14);
    }
    else if (frequency === 'monthly') {
        const targetMonth = dt.getUTCMonth() + 1;
        dt.setUTCMonth(targetMonth);
    }
    else if (frequency === 'yearly') {
        dt.setUTCFullYear(dt.getUTCFullYear() + 1);
    }
    return dt.toISOString().slice(0, 10);
}
function getPreviousMonths(centerMonth, count = 6) {
    const [y, m] = centerMonth.split('-').map(Number);
    const result = [];
    for (let i = count - 1; i >= 0; i--) {
        const dt = new Date(Date.UTC(y, m - 1 - i, 1));
        const ym = dt.toISOString().slice(0, 7);
        result.push(ym);
    }
    return result;
}
function formatMonthShort(ym) {
    const [y, m] = ym.split('-').map(Number);
    const names = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
    return `${names[(m - 1) % 12]} '${String(y).slice(-2)}`;
}
function getTemplateCategoriesForProfileType(type) {
    if (type === 'business') {
        return [
            ['Client Revenue & Invoices', 'income', '#10b981', 'briefcase', null, 0.8],
            ['Consulting & Retainers', 'income', '#06b6d4', 'sparkles', null, 0.8],
            ['Software & Cloud SaaS', 'expense', '#6366f1', 'zap', 450, 0.8],
            ['Office & Equipment', 'expense', '#3b82f6', 'home', 800, 0.85],
            ['Marketing & Advertising', 'expense', '#ec4899', 'shopping-bag', 1200, 0.8],
            ['Travel & Client Meals', 'expense', '#f59e0b', 'utensils', 600, 0.8],
            ['Contractors & Legal', 'expense', '#8b5cf6', 'shield', 1500, 0.85],
        ];
    }
    if (type === 'child') {
        return [
            ['Weekly Allowance & Chores', 'income', '#10b981', 'sparkles', null, 0.8],
            ['Birthday & Holiday Gifts', 'income', '#06b6d4', 'gift', null, 0.8],
            ['Toys, Games & Hobbies', 'expense', '#f59e0b', 'gamepad', 60, 0.8],
            ['Snacks & Treats', 'expense', '#ec4899', 'utensils', 35, 0.8],
            ['Books & School Supplies', 'expense', '#3b82f6', 'book', 45, 0.8],
            ['Activities & Outings', 'expense', '#8b5cf6', 'ticket', 50, 0.8],
        ];
    }
    if (type === 'family') {
        return [
            ['Combined Household Income', 'income', '#10b981', 'briefcase', null, 0.8],
            ['Mortgage / Shared Rent', 'expense', '#6366f1', 'home', 2600, 0.9],
            ['Family Groceries & Household', 'expense', '#f59e0b', 'utensils', 1100, 0.8],
            ['Childcare & Education', 'expense', '#ec4899', 'heart', 900, 0.85],
            ['Home Utilities & Internet', 'expense', '#3b82f6', 'zap', 380, 0.85],
            ['Family Outings & Vacation', 'expense', '#f43f5e', 'shopping-bag', 500, 0.8],
        ];
    }
    // Default / Personal template
    return [
        ['Salary & Payroll', 'income', '#10b981', 'briefcase', null, 0.8],
        ['Freelance & Side Income', 'income', '#06b6d4', 'sparkles', null, 0.8],
        ['Housing & Rent', 'expense', '#6366f1', 'home', 1800, 0.9],
        ['Groceries & Dining', 'expense', '#f59e0b', 'utensils', 650, 0.8],
        ['Utilities & Internet', 'expense', '#3b82f6', 'zap', 280, 0.85],
        ['Transportation & Fuel', 'expense', '#ec4899', 'car', 350, 0.8],
        ['Subscriptions & Media', 'expense', '#8b5cf6', 'repeat', 120, 0.8],
        ['Health & Wellness', 'expense', '#14b8a6', 'heart', 250, 0.8],
        ['Entertainment & Shopping', 'expense', '#f43f5e', 'shopping-bag', 400, 0.8],
    ];
}
class BudgetDatabase {
    db;
    constructor(dbPath) {
        if (dbPath !== ':memory:') {
            const dir = node_path_1.default.dirname(dbPath);
            if (!node_fs_1.default.existsSync(dir)) {
                node_fs_1.default.mkdirSync(dir, { recursive: true });
            }
        }
        this.db = new node_sqlite_1.DatabaseSync(dbPath);
        this.db.exec('PRAGMA foreign_keys = ON;');
        this.initSchema();
        this.seedDefaultsIfEmpty();
        this.ensureSyncMetadata();
    }
    hasColumn(tableName, columnName) {
        const info = this.db
            .prepare(`PRAGMA table_info(${tableName})`)
            .all();
        return info.some((c) => c.name === columnName);
    }
    initSchema() {
        this.db.exec(`
      CREATE TABLE IF NOT EXISTS profiles (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT NOT NULL,
        type TEXT NOT NULL DEFAULT 'personal',
        color TEXT NOT NULL DEFAULT '#10b981',
        icon TEXT NOT NULL DEFAULT 'user',
        description TEXT NOT NULL DEFAULT '',
        created_at TEXT NOT NULL DEFAULT (datetime('now'))
      );

      CREATE TABLE IF NOT EXISTS categories (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        profile_id INTEGER NOT NULL DEFAULT 1,
        name TEXT NOT NULL,
        type TEXT NOT NULL CHECK(type IN ('income', 'expense')),
        color TEXT NOT NULL DEFAULT '#10b981',
        icon TEXT NOT NULL DEFAULT 'wallet',
        monthly_limit REAL,
        alert_threshold REAL NOT NULL DEFAULT 0.8,
        FOREIGN KEY (profile_id) REFERENCES profiles(id) ON DELETE CASCADE
      );

      CREATE TABLE IF NOT EXISTS recurring_rules (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        profile_id INTEGER NOT NULL DEFAULT 1,
        title TEXT NOT NULL,
        category_id INTEGER NOT NULL,
        type TEXT NOT NULL CHECK(type IN ('income', 'expense')),
        amount REAL NOT NULL CHECK(amount > 0),
        frequency TEXT NOT NULL CHECK(frequency IN ('weekly', 'biweekly', 'monthly', 'yearly')),
        next_due_date TEXT NOT NULL,
        auto_log INTEGER NOT NULL DEFAULT 1,
        active INTEGER NOT NULL DEFAULT 1,
        FOREIGN KEY (profile_id) REFERENCES profiles(id) ON DELETE CASCADE,
        FOREIGN KEY (category_id) REFERENCES categories(id) ON DELETE CASCADE
      );

      CREATE TABLE IF NOT EXISTS transactions (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        profile_id INTEGER NOT NULL DEFAULT 1,
        category_id INTEGER NOT NULL,
        type TEXT NOT NULL CHECK(type IN ('income', 'expense')),
        amount REAL NOT NULL CHECK(amount > 0),
        date TEXT NOT NULL,
        description TEXT NOT NULL,
        recurring_rule_id INTEGER,
        receipt_image TEXT,
        receipt_filename TEXT,
        receipt_raw_text TEXT,
        receipt_merchant TEXT,
        created_at TEXT NOT NULL DEFAULT (datetime('now')),
        FOREIGN KEY (profile_id) REFERENCES profiles(id) ON DELETE CASCADE,
        FOREIGN KEY (category_id) REFERENCES categories(id) ON DELETE RESTRICT,
        FOREIGN KEY (recurring_rule_id) REFERENCES recurring_rules(id) ON DELETE SET NULL
      );

      CREATE INDEX IF NOT EXISTS idx_transactions_date ON transactions(date);
      CREATE INDEX IF NOT EXISTS idx_transactions_category ON transactions(category_id);

      CREATE TABLE IF NOT EXISTS misc_lists (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        profile_id INTEGER NOT NULL DEFAULT 1,
        title TEXT NOT NULL,
        category_id INTEGER,
        target_budget REAL,
        notes TEXT NOT NULL DEFAULT '',
        status TEXT NOT NULL DEFAULT 'active' CHECK(status IN ('active', 'completed')),
        linked_transaction_id INTEGER,
        created_at TEXT NOT NULL DEFAULT (datetime('now')),
        FOREIGN KEY (profile_id) REFERENCES profiles(id) ON DELETE CASCADE,
        FOREIGN KEY (category_id) REFERENCES categories(id) ON DELETE SET NULL
      );

      CREATE TABLE IF NOT EXISTS misc_list_items (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        list_id INTEGER NOT NULL,
        name TEXT NOT NULL,
        quantity REAL NOT NULL DEFAULT 1,
        unit TEXT NOT NULL DEFAULT 'qty',
        estimated_price REAL NOT NULL DEFAULT 0,
        actual_price REAL,
        checked INTEGER NOT NULL DEFAULT 0,
        notes TEXT NOT NULL DEFAULT '',
        FOREIGN KEY (list_id) REFERENCES misc_lists(id) ON DELETE CASCADE
      );

      CREATE INDEX IF NOT EXISTS idx_misc_lists_profile ON misc_lists(profile_id);
      CREATE INDEX IF NOT EXISTS idx_misc_items_list ON misc_list_items(list_id);
    `);
        // Migrate existing databases to include receipt columns if missing
        const receiptCols = [
            'receipt_image',
            'receipt_filename',
            'receipt_raw_text',
            'receipt_merchant',
        ];
        for (const col of receiptCols) {
            if (!this.hasColumn('transactions', col)) {
                this.db.exec(`ALTER TABLE transactions ADD COLUMN ${col} TEXT;`);
            }
        }
        // Migrate existing databases to include profile_id if missing
        if (!this.hasColumn('categories', 'profile_id')) {
            this.db.exec('ALTER TABLE categories ADD COLUMN profile_id INTEGER NOT NULL DEFAULT 1;');
        }
        if (!this.hasColumn('recurring_rules', 'profile_id')) {
            this.db.exec('ALTER TABLE recurring_rules ADD COLUMN profile_id INTEGER NOT NULL DEFAULT 1;');
        }
        if (!this.hasColumn('transactions', 'profile_id')) {
            this.db.exec('ALTER TABLE transactions ADD COLUMN profile_id INTEGER NOT NULL DEFAULT 1;');
        }
        this.db.exec('CREATE INDEX IF NOT EXISTS idx_categories_profile ON categories(profile_id);');
        this.db.exec('CREATE INDEX IF NOT EXISTS idx_transactions_profile ON transactions(profile_id);');
        this.db.exec('CREATE INDEX IF NOT EXISTS idx_recurring_profile ON recurring_rules(profile_id);');
        // v3.0 Cross-Platform Authentication & Remote Sync Schema Additions
        this.db.exec(`
      CREATE TABLE IF NOT EXISTS users (
        id TEXT PRIMARY KEY,
        email TEXT NOT NULL UNIQUE,
        display_name TEXT NOT NULL DEFAULT '',
        password_hash TEXT NOT NULL DEFAULT '',
        auth_provider TEXT NOT NULL DEFAULT 'email',
        created_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ', 'now')),
        updated_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ', 'now'))
      );
    `);
        const syncedTables = [
            'profiles',
            'categories',
            'recurring_rules',
            'transactions',
            'misc_lists',
            'misc_list_items',
        ];
        for (const tbl of syncedTables) {
            if (!this.hasColumn(tbl, 'sync_id')) {
                this.db.exec(`ALTER TABLE ${tbl} ADD COLUMN sync_id TEXT;`);
            }
            if (!this.hasColumn(tbl, 'user_id')) {
                this.db.exec(`ALTER TABLE ${tbl} ADD COLUMN user_id TEXT;`);
            }
            if (!this.hasColumn(tbl, 'updated_at')) {
                this.db.exec(`ALTER TABLE ${tbl} ADD COLUMN updated_at TEXT;`);
            }
            if (!this.hasColumn(tbl, 'deleted_at')) {
                this.db.exec(`ALTER TABLE ${tbl} ADD COLUMN deleted_at TEXT;`);
            }
            this.db.exec(`CREATE INDEX IF NOT EXISTS idx_${tbl}_sync_id ON ${tbl}(sync_id);`);
            this.db.exec(`CREATE INDEX IF NOT EXISTS idx_${tbl}_user_updated ON ${tbl}(user_id, updated_at);`);
            // Automatic UTC timestamp trigger on local updates when updated_at is not explicitly overridden
            this.db.exec(`
        CREATE TRIGGER IF NOT EXISTS trg_${tbl}_auto_updated_at
        AFTER UPDATE ON ${tbl}
        FOR EACH ROW
        WHEN NEW.updated_at IS OLD.updated_at
        BEGIN
          UPDATE ${tbl}
          SET updated_at = strftime('%Y-%m-%dT%H:%M:%fZ', 'now')
          WHERE id = NEW.id;
        END;
      `);
        }
    }
    ensureSyncMetadata(defaultUserId) {
        const nowUtc = new Date().toISOString();
        // 1. Backfill profiles sync_id & updated_at (deterministic for default seeded profiles)
        const profiles = this.db
            .prepare('SELECT id, name, type, sync_id, updated_at, created_at FROM profiles')
            .all();
        const updateProfileMeta = this.db.prepare('UPDATE profiles SET sync_id = ?, updated_at = ? WHERE id = ?');
        for (const p of profiles) {
            if (!p.sync_id || !p.updated_at) {
                const isSeededDefault = p.id <= 3 &&
                    (p.name === 'Personal Budget' ||
                        p.name === 'Business & Consulting' ||
                        p.name === "Child's Account (Leo)");
                const sid = p.sync_id ||
                    (isSeededDefault
                        ? deterministicUuid(`profile:${p.type}:${p.name}`)
                        : node_crypto_1.default.randomUUID());
                const upd = p.updated_at ||
                    (p.created_at && p.created_at.includes('T') ? p.created_at : '2026-01-01T00:00:00.000Z');
                updateProfileMeta.run(sid, upd, p.id);
            }
        }
        // 2. Backfill categories sync_id & updated_at
        const cats = this.db
            .prepare(`SELECT c.id, c.name, c.type, c.sync_id, c.updated_at, p.name as profile_name
         FROM categories c
         LEFT JOIN profiles p ON p.id = c.profile_id`)
            .all();
        const updateCatMeta = this.db.prepare('UPDATE categories SET sync_id = ?, updated_at = ? WHERE id = ?');
        for (const c of cats) {
            if (!c.sync_id || !c.updated_at) {
                const sid = c.sync_id ||
                    (c.id <= 22 && c.profile_name
                        ? deterministicUuid(`category:${c.profile_name}:${c.type}:${c.name}`)
                        : node_crypto_1.default.randomUUID());
                const upd = c.updated_at || '2026-01-01T00:00:00.000Z';
                updateCatMeta.run(sid, upd, c.id);
            }
        }
        // 3. Backfill recurring_rules, transactions, misc_lists, misc_list_items
        const otherTables = [
            'recurring_rules',
            'transactions',
            'misc_lists',
            'misc_list_items',
        ];
        for (const tbl of otherTables) {
            const rows = this.db
                .prepare(`SELECT id, sync_id, updated_at FROM ${tbl} WHERE sync_id IS NULL OR updated_at IS NULL`)
                .all();
            if (rows.length > 0) {
                const stmt = this.db.prepare(`UPDATE ${tbl} SET sync_id = ?, updated_at = ? WHERE id = ?`);
                for (const r of rows) {
                    stmt.run(r.sync_id || node_crypto_1.default.randomUUID(), r.updated_at || nowUtc, r.id);
                }
            }
        }
        if (defaultUserId) {
            this.claimUnownedRecordsForUser(defaultUserId);
        }
    }
    seedDefaultsIfEmpty() {
        const profileCount = this.db.prepare('SELECT COUNT(*) as count FROM profiles').get().count;
        const insertProfile = this.db.prepare(`
      INSERT INTO profiles (name, type, color, icon, description)
      VALUES (?, ?, ?, ?, ?)
    `);
        if (profileCount === 0) {
            insertProfile.run('Personal Budget', 'personal', '#10b981', 'user', 'Primary personal checking, household expenses, and savings');
            insertProfile.run('Business & Consulting', 'business', '#6366f1', 'briefcase', 'Tax-deductible business expenses, SaaS tools, and client invoices');
            insertProfile.run("Child's Account (Leo)", 'child', '#f59e0b', 'smile', 'Weekly allowance, chores rewards, toys, and youth savings jar');
        }
        // Check if categories already exist for Personal (profile 1)
        const p1CatCount = this.db
            .prepare('SELECT COUNT(*) as count FROM categories WHERE profile_id = 1')
            .get().count;
        const now = new Date();
        const ym = now.toISOString().slice(0, 7);
        const prevMonth = getPreviousMonths(ym, 2)[0];
        const nextMonth = advanceDateByFrequency(`${ym}-01`, 'monthly');
        const insertCat = this.db.prepare(`
      INSERT INTO categories (profile_id, name, type, color, icon, monthly_limit, alert_threshold)
      VALUES (?, ?, ?, ?, ?, ?, ?)
    `);
        const insertTx = this.db.prepare(`
      INSERT INTO transactions (profile_id, category_id, type, amount, date, description, recurring_rule_id)
      VALUES (?, ?, ?, ?, ?, ?, ?)
    `);
        const insertRec = this.db.prepare(`
      INSERT INTO recurring_rules (profile_id, title, category_id, type, amount, frequency, next_due_date, auto_log, active)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
    `);
        if (p1CatCount === 0) {
            const defaultCategories = getTemplateCategoriesForProfileType('personal');
            const p1CatIds = [];
            for (const c of defaultCategories) {
                const res = insertCat.run(1, ...c);
                p1CatIds.push(Number(res.lastInsertRowid));
            }
            // Previous month sample entries
            insertTx.run(1, p1CatIds[0], 'income', 5200, `${prevMonth}-01`, 'Monthly Salary Deposit', null);
            insertTx.run(1, p1CatIds[2], 'expense', 1650, `${prevMonth}-02`, 'Apartment Rent', null);
            insertTx.run(1, p1CatIds[3], 'expense', 540, `${prevMonth}-11`, 'Grocery & Supermarket Runs', null);
            insertTx.run(1, p1CatIds[4], 'expense', 210, `${prevMonth}-15`, 'Electric & Fiber Internet', null);
            insertTx.run(1, p1CatIds[5], 'expense', 260, `${prevMonth}-19`, 'Gas & Transit Pass', null);
            insertTx.run(1, p1CatIds[8], 'expense', 310, `${prevMonth}-24`, 'Weekend Outing & Books', null);
            // Current month sample entries
            insertTx.run(1, p1CatIds[0], 'income', 5200, `${ym}-01`, 'Monthly Salary Deposit', null);
            insertTx.run(1, p1CatIds[1], 'income', 650, `${ym}-10`, 'Personal Side Project Dividend', null);
            insertTx.run(1, p1CatIds[2], 'expense', 1650, `${ym}-02`, 'Apartment Rent', null);
            insertTx.run(1, p1CatIds[3], 'expense', 565, `${ym}-08`, 'Whole Foods & Weekly Groceries', null);
            insertTx.run(1, p1CatIds[4], 'expense', 195, `${ym}-12`, 'City Power & Fiber Gigabit', null);
            insertTx.run(1, p1CatIds[6], 'expense', 108, `${ym}-14`, 'Cloud Storage, Music & Streaming', null);
            insertTx.run(1, p1CatIds[8], 'expense', 425, `${ym}-18`, 'Autumn Jacket & Concert Tickets', null);
            insertRec.run(1, 'Apartment Rent', p1CatIds[2], 'expense', 1650, 'monthly', `${nextMonth.slice(0, 7)}-02`, 1, 1);
            insertRec.run(1, 'Fiber Gigabit Internet', p1CatIds[4], 'expense', 85, 'monthly', `${nextMonth.slice(0, 7)}-12`, 1, 1);
            insertRec.run(1, 'Music & Cloud Bundle', p1CatIds[6], 'expense', 24.99, 'monthly', `${nextMonth.slice(0, 7)}-14`, 1, 1);
            insertRec.run(1, 'Gym Membership', p1CatIds[7], 'expense', 55, 'monthly', `${nextMonth.slice(0, 7)}-05`, 0, 1);
            insertRec.run(1, 'Primary Paycheck', p1CatIds[0], 'income', 2600, 'biweekly', `${nextMonth.slice(0, 7)}-01`, 0, 1);
        }
        // Seed Profile 2 (Business & Consulting) if empty
        const p2Exists = this.db.prepare('SELECT id FROM profiles WHERE id = 2').get();
        const p2CatCount = this.db
            .prepare('SELECT COUNT(*) as count FROM categories WHERE profile_id = 2')
            .get().count;
        if (p2Exists && p2CatCount === 0) {
            const bizCats = getTemplateCategoriesForProfileType('business');
            const bizCatIds = [];
            for (const c of bizCats) {
                const res = insertCat.run(2, ...c);
                bizCatIds.push(Number(res.lastInsertRowid));
            }
            insertTx.run(2, bizCatIds[0], 'income', 4800, `${ym}-05`, 'Acme Corp Retainer Invoice #104', null);
            insertTx.run(2, bizCatIds[1], 'income', 1450, `${ym}-14`, 'Architecture Advisory Sprint', null);
            insertTx.run(2, bizCatIds[2], 'expense', 285, `${ym}-03`, 'AWS, GitHub Enterprise & Vercel Pro', null);
            insertTx.run(2, bizCatIds[3], 'expense', 420, `${ym}-09`, 'Ergonomic Monitor Arm & Dock', null);
            insertTx.run(2, bizCatIds[5], 'expense', 165, `${ym}-16`, 'Client Lunch & Airport Express', null);
            insertRec.run(2, 'AWS & Cloud Hosting', bizCatIds[2], 'expense', 190, 'monthly', `${nextMonth.slice(0, 7)}-03`, 1, 1);
            insertRec.run(2, 'Figma & Design Suite', bizCatIds[2], 'expense', 45, 'monthly', `${nextMonth.slice(0, 7)}-11`, 1, 1);
        }
        // Seed Profile 3 (Child's Account) if empty
        const p3Exists = this.db.prepare('SELECT id FROM profiles WHERE id = 3').get();
        const p3CatCount = this.db
            .prepare('SELECT COUNT(*) as count FROM categories WHERE profile_id = 3')
            .get().count;
        if (p3Exists && p3CatCount === 0) {
            const childCats = getTemplateCategoriesForProfileType('child');
            const childCatIds = [];
            for (const c of childCats) {
                const res = insertCat.run(3, ...c);
                childCatIds.push(Number(res.lastInsertRowid));
            }
            insertTx.run(3, childCatIds[0], 'income', 60, `${ym}-04`, 'Weekly Allowance & Lawn Chores', null);
            insertTx.run(3, childCatIds[1], 'income', 50, `${ym}-12`, 'Grandma Birthday Gift', null);
            insertTx.run(3, childCatIds[2], 'expense', 34.99, `${ym}-13`, 'LEGO Space Shuttle Set', null);
            insertTx.run(3, childCatIds[3], 'expense', 12.5, `${ym}-17`, 'Ice Cream & Smoothie Stop', null);
            insertTx.run(3, childCatIds[4], 'expense', 14.0, `${ym}-20`, 'Science Comic Book', null);
            insertRec.run(3, 'Weekly Allowance', childCatIds[0], 'income', 15, 'weekly', `${nextMonth.slice(0, 7)}-01`, 1, 1);
        }
        // Seed default Misc / Shopping Lists if none exist yet
        const listCount = this.db.prepare('SELECT COUNT(*) as count FROM misc_lists').get().count;
        if (listCount === 0) {
            const insertList = this.db.prepare(`
        INSERT INTO misc_lists (profile_id, title, category_id, target_budget, notes, status)
        VALUES (?, ?, ?, ?, ?, 'active')
      `);
            const insertItem = this.db.prepare(`
        INSERT INTO misc_list_items (list_id, name, quantity, unit, estimated_price, actual_price, checked, notes)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?)
      `);
            const p1GroceryCat = this.getCategories(1).find((c) => c.name.includes('Groceries'))?.id ?? null;
            const p1HomeCat = this.getCategories(1).find((c) => c.name.includes('Housing'))?.id ?? null;
            // Personal List 1: Weekly Grocery & Market Run
            const groceryListId = Number(insertList.run(1, "Weekly Grocery & Farmer's Market Run", p1GroceryCat, 85.0, 'Saturday morning market & Trader Joe essentials').lastInsertRowid);
            insertItem.run(groceryListId, 'Organic Honeycrisp Apples', 2, 'lbs', 3.49, 3.25, 1, 'Crisp autumn batch');
            insertItem.run(groceryListId, 'Artisan Sourdough Loaf', 1, 'loaf', 5.99, 5.99, 1, 'Sliced');
            insertItem.run(groceryListId, 'Pasture-Raised Eggs (12ct)', 1, 'carton', 6.99, 7.29, 1, '');
            insertItem.run(groceryListId, 'Wild Alaskan Salmon Fillets', 1.5, 'lbs', 14.0, null, 0, 'For Sunday dinner');
            insertItem.run(groceryListId, 'Cold Brew Coffee Concentrate', 1, 'bottle', 8.99, null, 0, '');
            insertItem.run(groceryListId, 'Avocados & Cilantro Bundle', 1, 'pack', 5.49, null, 0, '');
            // Personal List 2: Home Maintenance & Patio Scratchpad
            const homeListId = Number(insertList.run(1, 'Patio & Home Hardware Scratchpad', p1HomeCat, 140.0, 'Items needed from hardware store before winter').lastInsertRowid);
            insertItem.run(homeListId, 'Warm White Outdoor String Lights', 2, 'box', 24.5, 22.99, 1, '48ft weatherproof');
            insertItem.run(homeListId, 'Window Draft Weatherstripping', 3, 'roll', 9.99, null, 0, '');
            insertItem.run(homeListId, 'Potting Soil & Planter Saucer', 1, 'set', 18.0, null, 0, '');
            // Business List: Q4 Studio Office Upgrade
            const p2OfficeCat = this.getCategories(2).find((c) => c.name.includes('Office'))?.id ?? null;
            if (p2OfficeCat !== null) {
                const bizListId = Number(insertList.run(2, 'Q4 Studio Desk & Supply Order', p2OfficeCat, 250.0, 'Tax-deductible office peripherals and cables').lastInsertRowid);
                insertItem.run(bizListId, 'Thunderbolt 4 Braided Cables', 2, 'qty', 29.0, 27.5, 1, '2m length');
                insertItem.run(bizListId, 'Key Light Desk Mount Clamp', 1, 'qty', 49.0, null, 0, '');
                insertItem.run(bizListId, 'Printer Paper & Shipping Labels', 1, 'pack', 34.0, null, 0, '');
            }
            // Child List: Science Fair & Wishlist
            const p3ToyCat = this.getCategories(3).find((c) => c.name.includes('Toys'))?.id ?? null;
            if (p3ToyCat !== null) {
                const childListId = Number(insertList.run(3, 'Science Fair & LEGO Wishlist', p3ToyCat, 45.0, 'Saving up weekly allowance for these items').lastInsertRowid);
                insertItem.run(childListId, 'Tri-Fold Poster Board & Markers', 1, 'set', 9.5, 9.25, 1, 'For volcano project');
                insertItem.run(childListId, 'Mini Solar Rover Kit', 1, 'kit', 18.99, null, 0, '');
            }
        }
    }
    // ==================== PROFILES ====================
    getProfiles() {
        return this.db
            .prepare('SELECT * FROM profiles ORDER BY id ASC')
            .all();
    }
    getProfilesOverview(month) {
        const profiles = this.getProfiles();
        return profiles.map((profile) => {
            const summary = this.getDashboardSummary(month, profile.id);
            const categories = this.getCategories(profile.id);
            const monthTxs = this.getTransactions({ profileId: profile.id, month });
            return {
                profile,
                month,
                totalIncome: summary.totalIncome,
                totalExpense: summary.totalExpense,
                netSavings: summary.netSavings,
                categoryCount: categories.length,
                transactionCount: monthTxs.length,
                activeRecurringCount: summary.upcomingRecurring.length,
                alertCount: summary.alerts.length,
            };
        });
    }
    createProfile(input) {
        const res = this.db
            .prepare(`
        INSERT INTO profiles (name, type, color, icon, description)
        VALUES (?, ?, ?, ?, ?)
      `)
            .run(input.name.trim(), input.type, input.color || '#10b981', input.icon || 'user', input.description?.trim() || '');
        const newProfileId = Number(res.lastInsertRowid);
        if (input.seedTemplate !== false) {
            const templateCats = getTemplateCategoriesForProfileType(input.type);
            const insertCat = this.db.prepare(`
        INSERT INTO categories (profile_id, name, type, color, icon, monthly_limit, alert_threshold)
        VALUES (?, ?, ?, ?, ?, ?, ?)
      `);
            for (const c of templateCats) {
                insertCat.run(newProfileId, ...c);
            }
        }
        return this.db
            .prepare('SELECT * FROM profiles WHERE id = ?')
            .get(newProfileId);
    }
    updateProfile(input) {
        this.db
            .prepare(`
        UPDATE profiles
        SET name = ?, type = ?, color = ?, description = ?
        WHERE id = ?
      `)
            .run(input.name.trim(), input.type, input.color, input.description.trim(), input.id);
        return this.db
            .prepare('SELECT * FROM profiles WHERE id = ?')
            .get(input.id);
    }
    deleteProfile(id) {
        const profiles = this.getProfiles();
        if (profiles.length <= 1) {
            throw new Error('Cannot delete the last remaining profile.');
        }
        // Delete child records explicitly in case RESTRICT applies on transactions->categories
        this.db.prepare('DELETE FROM transactions WHERE profile_id = ?').run(id);
        this.db.prepare('DELETE FROM recurring_rules WHERE profile_id = ?').run(id);
        this.db.prepare('DELETE FROM misc_lists WHERE profile_id = ?').run(id);
        this.db.prepare('DELETE FROM categories WHERE profile_id = ?').run(id);
        const res = this.db.prepare('DELETE FROM profiles WHERE id = ?').run(id);
        return Number(res.changes) > 0;
    }
    transferBetweenProfiles(input) {
        if (input.fromProfileId === input.toProfileId) {
            throw new Error('Source and destination profiles must be different.');
        }
        const fromProfile = this.db
            .prepare('SELECT * FROM profiles WHERE id = ?')
            .get(input.fromProfileId);
        const toProfile = this.db
            .prepare('SELECT * FROM profiles WHERE id = ?')
            .get(input.toProfileId);
        if (!fromProfile || !toProfile) {
            throw new Error('Profile not found.');
        }
        const fromCats = this.getCategories(input.fromProfileId);
        const toCats = this.getCategories(input.toProfileId);
        let outCat = fromCats.find((c) => c.type === 'expense');
        if (!outCat) {
            outCat = this.createCategory({
                profile_id: input.fromProfileId,
                name: 'Profile Transfers',
                type: 'expense',
                color: '#6366f1',
                icon: 'repeat',
                monthly_limit: null,
                alert_threshold: 0.8,
            });
        }
        let inCat = toCats.find((c) => c.type === 'income');
        if (!inCat) {
            inCat = this.createCategory({
                profile_id: input.toProfileId,
                name: 'Transfers & Allowance In',
                type: 'income',
                color: '#10b981',
                icon: 'sparkles',
                monthly_limit: null,
                alert_threshold: 0.8,
            });
        }
        const note = input.description.trim() || 'Inter-Profile Transfer';
        const outTransaction = this.createTransaction({
            profile_id: input.fromProfileId,
            category_id: outCat.id,
            type: 'expense',
            amount: input.amount,
            date: input.date,
            description: `${note} (Transfer to ${toProfile.name})`,
        });
        const inTransaction = this.createTransaction({
            profile_id: input.toProfileId,
            category_id: inCat.id,
            type: 'income',
            amount: input.amount,
            date: input.date,
            description: `${note} (Transfer from ${fromProfile.name})`,
        });
        return { outTransaction, inTransaction };
    }
    // ==================== CATEGORIES ====================
    getCategories(profileId = 1) {
        return this.db
            .prepare('SELECT * FROM categories WHERE profile_id = ? ORDER BY type ASC, name ASC')
            .all(profileId);
    }
    createCategory(input) {
        const profileId = input.profile_id ?? 1;
        const stmt = this.db.prepare(`
      INSERT INTO categories (profile_id, name, type, color, icon, monthly_limit, alert_threshold)
      VALUES (?, ?, ?, ?, ?, ?, ?)
    `);
        const result = stmt.run(profileId, input.name.trim(), input.type, input.color, input.icon || 'tag', input.monthly_limit, input.alert_threshold ?? 0.8);
        return this.db
            .prepare('SELECT * FROM categories WHERE id = ?')
            .get(Number(result.lastInsertRowid));
    }
    updateCategoryBudget(input) {
        const existing = this.db
            .prepare('SELECT * FROM categories WHERE id = ?')
            .get(input.id);
        if (!existing) {
            throw new Error(`Category ${input.id} not found`);
        }
        this.db
            .prepare(`
        UPDATE categories
        SET name = ?, color = ?, monthly_limit = ?, alert_threshold = ?
        WHERE id = ?
      `)
            .run(input.name?.trim() || existing.name, input.color || existing.color, input.monthly_limit, input.alert_threshold, input.id);
        return this.db
            .prepare('SELECT * FROM categories WHERE id = ?')
            .get(input.id);
    }
    deleteCategory(id) {
        const res = this.db.prepare('DELETE FROM categories WHERE id = ?').run(id);
        return Number(res.changes) > 0;
    }
    // ==================== TRANSACTIONS ====================
    getTransactions(filters) {
        const clauses = [];
        const params = [];
        const profileId = filters?.profileId ?? 1;
        clauses.push('t.profile_id = ?');
        params.push(profileId);
        if (filters?.month) {
            clauses.push('substr(t.date, 1, 7) = ?');
            params.push(filters.month);
        }
        if (filters?.categoryId) {
            clauses.push('t.category_id = ?');
            params.push(filters.categoryId);
        }
        if (filters?.type) {
            clauses.push('t.type = ?');
            params.push(filters.type);
        }
        if (filters?.search && filters.search.trim()) {
            clauses.push("(LOWER(t.description) LIKE ? OR LOWER(c.name) LIKE ? OR LOWER(COALESCE(t.receipt_merchant, '')) LIKE ? OR LOWER(COALESCE(t.receipt_raw_text, '')) LIKE ?)");
            const pat = `%${filters.search.trim().toLowerCase()}%`;
            params.push(pat, pat, pat, pat);
        }
        const whereSql = clauses.length > 0 ? `WHERE ${clauses.join(' AND ')}` : '';
        const sql = `
      SELECT
        t.*,
        c.name as category_name,
        c.color as category_color,
        c.icon as category_icon
      FROM transactions t
      LEFT JOIN categories c ON c.id = t.category_id
      ${whereSql}
      ORDER BY t.date DESC, t.id DESC
    `;
        return this.db.prepare(sql).all(...params);
    }
    createTransaction(input) {
        const cat = this.db
            .prepare('SELECT profile_id FROM categories WHERE id = ?')
            .get(input.category_id);
        const profileId = input.profile_id ?? cat?.profile_id ?? 1;
        const stmt = this.db.prepare(`
      INSERT INTO transactions (
        profile_id, category_id, type, amount, date, description, recurring_rule_id,
        receipt_image, receipt_filename, receipt_raw_text, receipt_merchant
      )
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    `);
        const res = stmt.run(profileId, input.category_id, input.type, Number(input.amount), input.date, input.description.trim(), input.recurring_rule_id ?? null, input.receipt_image ?? null, input.receipt_filename ?? null, input.receipt_raw_text ?? null, input.receipt_merchant ?? null);
        const id = Number(res.lastInsertRowid);
        return this.db
            .prepare(`
        SELECT t.*, c.name as category_name, c.color as category_color, c.icon as category_icon
        FROM transactions t
        LEFT JOIN categories c ON c.id = t.category_id
        WHERE t.id = ?
      `)
            .get(id);
    }
    updateTransaction(input) {
        const existing = this.db
            .prepare('SELECT * FROM transactions WHERE id = ?')
            .get(input.id);
        this.db
            .prepare(`
        UPDATE transactions
        SET category_id = ?, type = ?, amount = ?, date = ?, description = ?,
            receipt_image = ?, receipt_filename = ?, receipt_raw_text = ?, receipt_merchant = ?
        WHERE id = ?
      `)
            .run(input.category_id, input.type, Number(input.amount), input.date, input.description.trim(), input.receipt_image !== undefined ? input.receipt_image : (existing?.receipt_image ?? null), input.receipt_filename !== undefined ? input.receipt_filename : (existing?.receipt_filename ?? null), input.receipt_raw_text !== undefined ? input.receipt_raw_text : (existing?.receipt_raw_text ?? null), input.receipt_merchant !== undefined ? input.receipt_merchant : (existing?.receipt_merchant ?? null), input.id);
        return this.db
            .prepare(`
        SELECT t.*, c.name as category_name, c.color as category_color, c.icon as category_icon
        FROM transactions t
        LEFT JOIN categories c ON c.id = t.category_id
        WHERE t.id = ?
      `)
            .get(input.id);
    }
    parseReceipt(rawText, profileId = 1) {
        return (0, receiptParser_1.parseReceiptText)(rawText, this.getCategories(profileId));
    }
    deleteTransaction(id) {
        const res = this.db.prepare('DELETE FROM transactions WHERE id = ?').run(id);
        return Number(res.changes) > 0;
    }
    // ==================== RECURRING RULES ====================
    getRecurringRules(profileId = 1) {
        return this.db
            .prepare(`
        SELECT r.*, c.name as category_name, c.color as category_color
        FROM recurring_rules r
        LEFT JOIN categories c ON c.id = r.category_id
        WHERE r.profile_id = ?
        ORDER BY r.active DESC, r.next_due_date ASC
      `)
            .all(profileId);
    }
    createRecurringRule(input) {
        const cat = this.db
            .prepare('SELECT profile_id FROM categories WHERE id = ?')
            .get(input.category_id);
        const profileId = input.profile_id ?? cat?.profile_id ?? 1;
        const res = this.db
            .prepare(`
        INSERT INTO recurring_rules (profile_id, title, category_id, type, amount, frequency, next_due_date, auto_log, active)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
      `)
            .run(profileId, input.title.trim(), input.category_id, input.type, Number(input.amount), input.frequency, input.next_due_date, input.auto_log ? 1 : 0, input.active === false ? 0 : 1);
        const id = Number(res.lastInsertRowid);
        return this.db
            .prepare(`
        SELECT r.*, c.name as category_name, c.color as category_color
        FROM recurring_rules r
        LEFT JOIN categories c ON c.id = r.category_id
        WHERE r.id = ?
      `)
            .get(id);
    }
    toggleRecurringRule(id, active) {
        this.db
            .prepare('UPDATE recurring_rules SET active = ? WHERE id = ?')
            .run(active ? 1 : 0, id);
        return this.db
            .prepare(`
        SELECT r.*, c.name as category_name, c.color as category_color
        FROM recurring_rules r
        LEFT JOIN categories c ON c.id = r.category_id
        WHERE r.id = ?
      `)
            .get(id);
    }
    triggerRecurringRuleNow(id, dateOverride) {
        const rule = this.db
            .prepare('SELECT * FROM recurring_rules WHERE id = ?')
            .get(id);
        if (!rule) {
            throw new Error(`Recurring rule ${id} not found`);
        }
        const txDate = dateOverride || rule.next_due_date;
        const transaction = this.createTransaction({
            profile_id: rule.profile_id,
            category_id: rule.category_id,
            type: rule.type,
            amount: rule.amount,
            date: txDate,
            description: `${rule.title} (Recurring)`,
            recurring_rule_id: rule.id,
        });
        const nextDate = advanceDateByFrequency(rule.next_due_date, rule.frequency);
        this.db
            .prepare('UPDATE recurring_rules SET next_due_date = ? WHERE id = ?')
            .run(nextDate, rule.id);
        const updatedRule = this.db
            .prepare(`
        SELECT r.*, c.name as category_name, c.color as category_color
        FROM recurring_rules r
        LEFT JOIN categories c ON c.id = r.category_id
        WHERE r.id = ?
      `)
            .get(rule.id);
        return { transaction, updatedRule };
    }
    deleteRecurringRule(id) {
        const res = this.db.prepare('DELETE FROM recurring_rules WHERE id = ?').run(id);
        return Number(res.changes) > 0;
    }
    processDueRecurringRules(todayDate) {
        const today = todayDate || new Date().toISOString().slice(0, 10);
        const dueRules = this.db
            .prepare(`
        SELECT * FROM recurring_rules
        WHERE active = 1 AND auto_log = 1 AND next_due_date <= ?
      `)
            .all(today);
        let createdCount = 0;
        for (const rule of dueRules) {
            let currentDue = rule.next_due_date;
            let safety = 0;
            while (currentDue <= today && safety < 24) {
                this.createTransaction({
                    profile_id: rule.profile_id,
                    category_id: rule.category_id,
                    type: rule.type,
                    amount: rule.amount,
                    date: currentDue,
                    description: `${rule.title} (Auto-logged)`,
                    recurring_rule_id: rule.id,
                });
                currentDue = advanceDateByFrequency(currentDue, rule.frequency);
                createdCount++;
                safety++;
            }
            this.db
                .prepare('UPDATE recurring_rules SET next_due_date = ? WHERE id = ?')
                .run(currentDue, rule.id);
        }
        return createdCount;
    }
    getDashboardSummary(month, profileId = 1) {
        const categories = this.getCategories(profileId);
        const monthTransactions = this.getTransactions({ profileId, month });
        let totalIncome = 0;
        let totalExpense = 0;
        const spentByCategory = new Map();
        for (const tx of monthTransactions) {
            if (tx.type === 'income') {
                totalIncome += tx.amount;
            }
            else {
                totalExpense += tx.amount;
                spentByCategory.set(tx.category_id, (spentByCategory.get(tx.category_id) || 0) + tx.amount);
            }
        }
        const netSavings = totalIncome - totalExpense;
        const savingsRate = totalIncome > 0 ? (netSavings / totalIncome) * 100 : 0;
        const expenseCategories = categories.filter((c) => c.type === 'expense');
        const categoryBudgets = expenseCategories.map((category) => {
            const spent = spentByCategory.get(category.id) || 0;
            const limit = category.monthly_limit;
            if (limit === null || limit <= 0) {
                return {
                    category,
                    spent,
                    limit: null,
                    percentage: null,
                    remaining: null,
                    status: 'unbounded',
                };
            }
            const ratio = spent / limit;
            const percentage = ratio * 100;
            const remaining = limit - spent;
            let status = 'healthy';
            if (ratio >= 1) {
                status = 'exceeded';
            }
            else if (ratio >= category.alert_threshold) {
                status = 'warning';
            }
            return {
                category,
                spent,
                limit,
                percentage,
                remaining,
                status,
            };
        });
        const alerts = categoryBudgets.filter((cb) => cb.status === 'warning' || cb.status === 'exceeded');
        const trendMonths = getPreviousMonths(month, 6);
        const monthlyTrends = trendMonths.map((ym) => {
            const rows = this.db
                .prepare(`
          SELECT type, COALESCE(SUM(amount), 0) as total
          FROM transactions
          WHERE profile_id = ? AND substr(date, 1, 7) = ?
          GROUP BY type
        `)
                .all(profileId, ym);
            let inc = 0;
            let exp = 0;
            for (const r of rows) {
                if (r.type === 'income')
                    inc = r.total;
                if (r.type === 'expense')
                    exp = r.total;
            }
            return {
                month: ym,
                label: formatMonthShort(ym),
                income: inc,
                expense: exp,
                net: inc - exp,
            };
        });
        const upcomingRecurring = this.getRecurringRules(profileId).filter((r) => r.active === 1);
        return {
            profileId,
            month,
            totalIncome,
            totalExpense,
            netSavings,
            savingsRate,
            categoryBudgets,
            alerts,
            monthlyTrends,
            upcomingRecurring,
            recentTransactions: monthTransactions.slice(0, 8),
        };
    }
    // ==================== DATA EXCHANGE & USER TESTING ====================
    exportBackupBundle() {
        const profiles = this.db
            .prepare('SELECT * FROM profiles ORDER BY id ASC')
            .all();
        const categories = this.db
            .prepare('SELECT * FROM categories ORDER BY id ASC')
            .all();
        const transactions = this.db
            .prepare('SELECT * FROM transactions ORDER BY id ASC')
            .all();
        const recurringRules = this.db
            .prepare('SELECT * FROM recurring_rules ORDER BY id ASC')
            .all();
        return {
            app: 'LedgerPulse',
            version: '1.0.0',
            exportedAt: new Date().toISOString(),
            profiles,
            categories,
            transactions,
            recurringRules,
        };
    }
    importBackupBundle(bundle) {
        if (!bundle || !Array.isArray(bundle.profiles) || !Array.isArray(bundle.categories)) {
            throw new Error('Invalid LedgerPulse backup bundle format.');
        }
        this.db.exec('PRAGMA foreign_keys = OFF;');
        try {
            this.db.exec('BEGIN TRANSACTION;');
            this.db.exec('DELETE FROM transactions;');
            this.db.exec('DELETE FROM recurring_rules;');
            this.db.exec('DELETE FROM categories;');
            this.db.exec('DELETE FROM profiles;');
            const insProf = this.db.prepare(`
        INSERT INTO profiles (id, name, type, color, icon, description, created_at)
        VALUES (?, ?, ?, ?, ?, ?, ?)
      `);
            for (const p of bundle.profiles) {
                insProf.run(p.id, p.name, p.type || 'personal', p.color || '#10b981', p.icon || 'user', p.description || '', p.created_at || new Date().toISOString());
            }
            const insCat = this.db.prepare(`
        INSERT INTO categories (id, profile_id, name, type, color, icon, monthly_limit, alert_threshold)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?)
      `);
            for (const c of bundle.categories) {
                insCat.run(c.id, c.profile_id ?? 1, c.name, c.type, c.color || '#10b981', c.icon || 'tag', c.monthly_limit ?? null, c.alert_threshold ?? 0.8);
            }
            const insRec = this.db.prepare(`
        INSERT INTO recurring_rules (id, profile_id, title, category_id, type, amount, frequency, next_due_date, auto_log, active)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
      `);
            for (const r of bundle.recurringRules || []) {
                insRec.run(r.id, r.profile_id ?? 1, r.title, r.category_id, r.type, r.amount, r.frequency, r.next_due_date, r.auto_log ?? 1, r.active ?? 1);
            }
            const insTx = this.db.prepare(`
        INSERT INTO transactions (
          id, profile_id, category_id, type, amount, date, description,
          recurring_rule_id, receipt_image, receipt_filename, receipt_raw_text, receipt_merchant, created_at
        )
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
      `);
            for (const t of bundle.transactions || []) {
                insTx.run(t.id, t.profile_id ?? 1, t.category_id, t.type, t.amount, t.date, t.description, t.recurring_rule_id ?? null, t.receipt_image ?? null, t.receipt_filename ?? null, t.receipt_raw_text ?? null, t.receipt_merchant ?? null, t.created_at || new Date().toISOString());
            }
            this.db.exec('COMMIT;');
        }
        catch (err) {
            this.db.exec('ROLLBACK;');
            throw err;
        }
        finally {
            this.db.exec('PRAGMA foreign_keys = ON;');
        }
        return {
            profiles: bundle.profiles.length,
            categories: bundle.categories.length,
            transactions: (bundle.transactions || []).length,
            recurringRules: (bundle.recurringRules || []).length,
        };
    }
    exportTransactionsCsv(options) {
        const clauses = [];
        const params = [];
        if (options?.profileId) {
            clauses.push('t.profile_id = ?');
            params.push(options.profileId);
        }
        if (options?.month) {
            clauses.push('substr(t.date, 1, 7) = ?');
            params.push(options.month);
        }
        const whereSql = clauses.length > 0 ? `WHERE ${clauses.join(' AND ')}` : '';
        const rows = this.db
            .prepare(`
        SELECT
          t.id,
          p.name as profile_name,
          p.type as profile_type,
          t.date,
          t.type,
          c.name as category_name,
          t.amount,
          t.description,
          COALESCE(t.receipt_merchant, '') as receipt_merchant,
          COALESCE(t.receipt_filename, '') as receipt_filename
        FROM transactions t
        LEFT JOIN profiles p ON p.id = t.profile_id
        LEFT JOIN categories c ON c.id = t.category_id
        ${whereSql}
        ORDER BY t.date DESC, t.id DESC
      `)
            .all(...params);
        const escapeCsv = (val) => {
            const str = String(val ?? '');
            if (/[",\r\n]/.test(str)) {
                return `"${str.replace(/"/g, '""')}"`;
            }
            return str;
        };
        const headers = [
            'ID',
            'Profile',
            'Profile Type',
            'Date',
            'Entry Type',
            'Category',
            'Amount',
            'Description',
            'Receipt Merchant',
            'Receipt File',
        ];
        const lines = [headers.join(',')];
        for (const r of rows) {
            lines.push([
                r.id,
                r.profile_name,
                r.profile_type,
                r.date,
                r.type,
                r.category_name,
                Number(r.amount).toFixed(2),
                r.description,
                r.receipt_merchant,
                r.receipt_filename,
            ]
                .map(escapeCsv)
                .join(','));
        }
        return lines.join('\n');
    }
    resetDemoData() {
        this.db.exec('PRAGMA foreign_keys = OFF;');
        try {
            this.db.exec('DELETE FROM misc_list_items;');
            this.db.exec('DELETE FROM misc_lists;');
            this.db.exec('DELETE FROM transactions;');
            this.db.exec('DELETE FROM recurring_rules;');
            this.db.exec('DELETE FROM categories;');
            this.db.exec('DELETE FROM profiles;');
            this.db.exec("DELETE FROM sqlite_sequence WHERE name IN ('profiles','categories','transactions','recurring_rules','misc_lists','misc_list_items');");
        }
        finally {
            this.db.exec('PRAGMA foreign_keys = ON;');
        }
        this.seedDefaultsIfEmpty();
        return true;
    }
    // ==================== MISC LEDGER / SHOPPING LISTS ====================
    enrichMiscList(listRow) {
        const items = this.db
            .prepare('SELECT * FROM misc_list_items WHERE list_id = ? ORDER BY checked ASC, id ASC')
            .all(listRow.id);
        let plannedTotal = 0;
        let checkedTotal = 0;
        let effectiveTotal = 0;
        let checkedCount = 0;
        for (const item of items) {
            const qty = Number(item.quantity) || 1;
            const est = Number(item.estimated_price) || 0;
            const act = item.actual_price !== null && item.actual_price !== undefined ? Number(item.actual_price) : est;
            plannedTotal += qty * est;
            effectiveTotal += qty * act;
            if (item.checked === 1) {
                checkedCount++;
                checkedTotal += qty * act;
            }
        }
        return {
            ...listRow,
            items,
            plannedTotal: Number(plannedTotal.toFixed(2)),
            checkedTotal: Number(checkedTotal.toFixed(2)),
            effectiveTotal: Number(effectiveTotal.toFixed(2)),
            checkedCount,
            totalItemCount: items.length,
        };
    }
    getMiscLists(profileId = 1) {
        const rows = this.db
            .prepare(`
        SELECT l.*, c.name as category_name, c.color as category_color
        FROM misc_lists l
        LEFT JOIN categories c ON c.id = l.category_id
        WHERE l.profile_id = ?
        ORDER BY l.status ASC, l.id DESC
      `)
            .all(profileId);
        return rows.map((r) => this.enrichMiscList(r));
    }
    createMiscList(input) {
        const profileId = input.profile_id ?? 1;
        const res = this.db
            .prepare(`
        INSERT INTO misc_lists (profile_id, title, category_id, target_budget, notes, status)
        VALUES (?, ?, ?, ?, ?, 'active')
      `)
            .run(profileId, input.title.trim(), input.category_id ?? null, input.target_budget ?? null, input.notes?.trim() || '');
        const id = Number(res.lastInsertRowid);
        const row = this.db
            .prepare(`
        SELECT l.*, c.name as category_name, c.color as category_color
        FROM misc_lists l
        LEFT JOIN categories c ON c.id = l.category_id
        WHERE l.id = ?
      `)
            .get(id);
        return this.enrichMiscList(row);
    }
    deleteMiscList(id) {
        this.db.prepare('DELETE FROM misc_list_items WHERE list_id = ?').run(id);
        const res = this.db.prepare('DELETE FROM misc_lists WHERE id = ?').run(id);
        return Number(res.changes) > 0;
    }
    addMiscListItem(input) {
        const res = this.db
            .prepare(`
        INSERT INTO misc_list_items (list_id, name, quantity, unit, estimated_price, actual_price, checked, notes)
        VALUES (?, ?, ?, ?, ?, ?, 0, ?)
      `)
            .run(input.list_id, input.name.trim(), Number(input.quantity) || 1, input.unit?.trim() || 'qty', Number(input.estimated_price) || 0, input.actual_price !== undefined && input.actual_price !== null
            ? Number(input.actual_price)
            : null, input.notes?.trim() || '');
        const id = Number(res.lastInsertRowid);
        return this.db
            .prepare('SELECT * FROM misc_list_items WHERE id = ?')
            .get(id);
    }
    updateMiscListItem(input) {
        const existing = this.db
            .prepare('SELECT * FROM misc_list_items WHERE id = ?')
            .get(input.id);
        if (!existing) {
            throw new Error(`List item ${input.id} not found`);
        }
        this.db
            .prepare(`
        UPDATE misc_list_items
        SET name = ?, quantity = ?, unit = ?, estimated_price = ?, actual_price = ?, checked = ?, notes = ?
        WHERE id = ?
      `)
            .run(input.name !== undefined ? input.name.trim() : existing.name, input.quantity !== undefined ? Number(input.quantity) : existing.quantity, input.unit !== undefined ? input.unit.trim() : existing.unit, input.estimated_price !== undefined ? Number(input.estimated_price) : existing.estimated_price, input.actual_price !== undefined ? input.actual_price : existing.actual_price, input.checked !== undefined ? (input.checked ? 1 : 0) : existing.checked, input.notes !== undefined ? input.notes.trim() : existing.notes, input.id);
        return this.db
            .prepare('SELECT * FROM misc_list_items WHERE id = ?')
            .get(input.id);
    }
    deleteMiscListItem(id) {
        const res = this.db.prepare('DELETE FROM misc_list_items WHERE id = ?').run(id);
        return Number(res.changes) > 0;
    }
    checkoutMiscListToTransaction(input) {
        const rawList = this.db
            .prepare(`
        SELECT l.*, c.name as category_name, c.color as category_color
        FROM misc_lists l
        LEFT JOIN categories c ON c.id = l.category_id
        WHERE l.id = ?
      `)
            .get(input.list_id);
        if (!rawList) {
            throw new Error(`Misc list ${input.list_id} not found`);
        }
        const enriched = this.enrichMiscList(rawList);
        const targetItems = input.mode === 'checked_only'
            ? enriched.items.filter((i) => i.checked === 1)
            : enriched.items;
        if (targetItems.length === 0) {
            throw new Error('No items selected to convert into a transaction.');
        }
        let totalAmount = 0;
        const itemizedLines = [
            `${enriched.title.toUpperCase()} — ITEMIZED CHECKOUT`,
            `Date: ${input.date}`,
            '-----------------------------------------',
        ];
        for (const item of targetItems) {
            const qty = Number(item.quantity) || 1;
            const unitPrice = item.actual_price !== null && item.actual_price !== undefined
                ? Number(item.actual_price)
                : Number(item.estimated_price) || 0;
            const lineTotal = qty * unitPrice;
            totalAmount += lineTotal;
            itemizedLines.push(`${item.name} (${qty} ${item.unit} @ $${unitPrice.toFixed(2)})   $${lineTotal.toFixed(2)}`);
        }
        itemizedLines.push('-----------------------------------------');
        itemizedLines.push(`TOTAL                                    $${totalAmount.toFixed(2)}`);
        const finalAmount = Number(Math.max(0.01, totalAmount).toFixed(2));
        const description = input.description?.trim() ||
            `${enriched.title} (${targetItems.length} item${targetItems.length > 1 ? 's' : ''})`;
        const transaction = this.createTransaction({
            profile_id: enriched.profile_id,
            category_id: input.category_id,
            type: 'expense',
            amount: finalAmount,
            date: input.date,
            description,
            receipt_raw_text: itemizedLines.join('\n'),
            receipt_merchant: enriched.title,
        });
        if (input.remove_checked_items && input.mode === 'checked_only') {
            this.db
                .prepare('DELETE FROM misc_list_items WHERE list_id = ? AND checked = 1')
                .run(enriched.id);
        }
        else if (input.mode === 'all_items') {
            this.db
                .prepare('UPDATE misc_list_items SET checked = 1 WHERE list_id = ?')
                .run(enriched.id);
            this.db
                .prepare("UPDATE misc_lists SET status = 'completed', linked_transaction_id = ? WHERE id = ?")
                .run(transaction.id, enriched.id);
        }
        else {
            this.db
                .prepare('UPDATE misc_lists SET linked_transaction_id = ? WHERE id = ?')
                .run(transaction.id, enriched.id);
        }
        const updatedRaw = this.db
            .prepare(`
        SELECT l.*, c.name as category_name, c.color as category_color
        FROM misc_lists l
        LEFT JOIN categories c ON c.id = l.category_id
        WHERE l.id = ?
      `)
            .get(enriched.id);
        return {
            transaction,
            updatedList: this.enrichMiscList(updatedRaw),
        };
    }
    // ============================================================================
    // LedgerPulse 3.0 — User Authentication & Last-Write-Wins (LWW) Remote Sync
    // ============================================================================
    hashPassword(password, emailSalt) {
        if (!password)
            return '';
        return node_crypto_1.default
            .scryptSync(password, `ledgerpulse-v3-salt:${emailSalt.toLowerCase().trim()}`, 32)
            .toString('hex');
    }
    registerUserAccount(input) {
        let emailClean = (input.email || '').trim().toLowerCase();
        if (emailClean && !emailClean.includes('@')) {
            emailClean = `${emailClean}@gmail.com`;
        }
        if (!emailClean || !emailClean.includes('@')) {
            emailClean = 'alex.morgan@gmail.com';
        }
        const nowUtc = new Date().toISOString();
        const userId = input.userId?.trim() || deterministicUuid(`user:${emailClean}`);
        const existing = this.db
            .prepare('SELECT * FROM users WHERE email = ? OR id = ?')
            .get(emailClean, userId);
        if (existing) {
            const updatedName = input.displayName?.trim() || existing.display_name || emailClean.split('@')[0];
            const updatedProvider = input.authProvider || existing.auth_provider || 'email';
            this.db
                .prepare('UPDATE users SET display_name = ?, auth_provider = ?, updated_at = ? WHERE id = ?')
                .run(updatedName, updatedProvider, nowUtc, existing.id);
            this.claimUnownedRecordsForUser(existing.id);
            return {
                id: existing.id,
                email: existing.email,
                display_name: updatedName,
                auth_provider: updatedProvider,
                created_at: existing.created_at,
                updated_at: nowUtc,
            };
        }
        const displayName = input.displayName?.trim() || emailClean.split('@')[0];
        const provider = input.authProvider || 'email';
        const pwHash = this.hashPassword(input.password || '', emailClean);
        this.db
            .prepare(`INSERT OR REPLACE INTO users (id, email, display_name, password_hash, auth_provider, created_at, updated_at)
         VALUES (?, ?, ?, ?, ?, ?, ?)`)
            .run(userId, emailClean, displayName, pwHash, provider, nowUtc, nowUtc);
        this.claimUnownedRecordsForUser(userId);
        return {
            id: userId,
            email: emailClean,
            display_name: displayName,
            auth_provider: provider,
            created_at: nowUtc,
            updated_at: nowUtc,
        };
    }
    loginUserAccount(input) {
        let emailClean = (input.email || '').trim().toLowerCase();
        if (emailClean && !emailClean.includes('@')) {
            emailClean = `${emailClean}@gmail.com`;
        }
        const existing = this.db
            .prepare('SELECT * FROM users WHERE email = ?')
            .get(emailClean);
        if (!existing) {
            // Auto-provision account on first login for frictionless cross-device setup
            return this.registerUserAccount(input);
        }
        const requestedProvider = input.authProvider || 'email';
        if (requestedProvider === 'email' &&
            existing.auth_provider === 'email' &&
            existing.password_hash &&
            input.password) {
            const candidateHash = this.hashPassword(input.password, emailClean);
            if (candidateHash !== existing.password_hash) {
                throw new Error('Invalid password for this account.');
            }
        }
        const nowUtc = new Date().toISOString();
        const updatedProvider = requestedProvider !== 'email' ? requestedProvider : existing.auth_provider;
        const updatedName = input.displayName?.trim() || existing.display_name;
        this.db
            .prepare('UPDATE users SET display_name = ?, auth_provider = ?, updated_at = ? WHERE id = ?')
            .run(updatedName, updatedProvider, nowUtc, existing.id);
        this.claimUnownedRecordsForUser(existing.id);
        return {
            id: existing.id,
            email: existing.email,
            display_name: updatedName,
            auth_provider: updatedProvider,
            created_at: existing.created_at,
            updated_at: nowUtc,
        };
    }
    claimUnownedRecordsForUser(userId) {
        this.ensureSyncMetadata();
        const tables = [
            'profiles',
            'categories',
            'recurring_rules',
            'transactions',
            'misc_lists',
            'misc_list_items',
        ];
        let claimedRecords = 0;
        for (const tbl of tables) {
            const res = this.db
                .prepare(`UPDATE ${tbl} SET user_id = ? WHERE user_id IS NULL OR user_id = ''`)
                .run(userId);
            claimedRecords += Number(res.changes || 0);
        }
        return { claimedRecords };
    }
    getSyncChangeset(userId, sinceUtc) {
        this.ensureSyncMetadata(userId);
        const sinceFilter = sinceUtc ? sinceUtc.trim() : null;
        const filterBySince = (rows) => {
            if (!sinceFilter)
                return rows;
            const sinceMs = Date.parse(sinceFilter);
            if (Number.isNaN(sinceMs))
                return rows;
            return rows.filter((r) => Date.parse(r.updated_at || '') > sinceMs);
        };
        const rawProfiles = this.db
            .prepare('SELECT * FROM profiles WHERE user_id = ? OR user_id IS NULL ORDER BY id ASC')
            .all(userId);
        const profileSyncById = new Map();
        for (const p of rawProfiles) {
            profileSyncById.set(p.id, p.sync_id);
        }
        const rawCategories = this.db
            .prepare('SELECT * FROM categories WHERE user_id = ? OR user_id IS NULL ORDER BY id ASC')
            .all(userId);
        const categorySyncById = new Map();
        for (const c of rawCategories) {
            categorySyncById.set(c.id, c.sync_id);
        }
        const rawRules = this.db
            .prepare('SELECT * FROM recurring_rules WHERE user_id = ? OR user_id IS NULL ORDER BY id ASC')
            .all(userId);
        const ruleSyncById = new Map();
        for (const r of rawRules) {
            ruleSyncById.set(r.id, r.sync_id);
        }
        const rawTransactions = this.db
            .prepare('SELECT * FROM transactions WHERE user_id = ? OR user_id IS NULL ORDER BY id ASC')
            .all(userId);
        const rawMiscLists = this.db
            .prepare('SELECT * FROM misc_lists WHERE user_id = ? OR user_id IS NULL ORDER BY id ASC')
            .all(userId);
        const listSyncById = new Map();
        for (const l of rawMiscLists) {
            listSyncById.set(l.id, l.sync_id);
        }
        const rawMiscItems = this.db
            .prepare('SELECT * FROM misc_list_items WHERE user_id = ? OR user_id IS NULL ORDER BY id ASC')
            .all(userId);
        const defaultProfileSyncId = rawProfiles[0]?.sync_id || deterministicUuid('profile:personal:Personal Budget');
        const defaultCategorySyncId = rawCategories[0]?.sync_id ||
            deterministicUuid('category:Personal Budget:income:Salary & Payroll');
        return {
            version: '3.0',
            userId,
            exportedAt: new Date().toISOString(),
            sinceUtc: sinceFilter,
            profiles: filterBySince(rawProfiles).map((p) => ({
                sync_id: p.sync_id,
                user_id: p.user_id || userId,
                name: p.name,
                type: p.type,
                color: p.color,
                icon: p.icon,
                description: p.description,
                created_at: p.created_at,
                updated_at: p.updated_at,
                deleted_at: p.deleted_at || null,
            })),
            categories: filterBySince(rawCategories).map((c) => ({
                sync_id: c.sync_id,
                user_id: c.user_id || userId,
                profile_sync_id: profileSyncById.get(c.profile_id) || defaultProfileSyncId,
                name: c.name,
                type: c.type,
                color: c.color,
                icon: c.icon,
                monthly_limit: c.monthly_limit,
                alert_threshold: c.alert_threshold,
                updated_at: c.updated_at,
                deleted_at: c.deleted_at || null,
            })),
            recurringRules: filterBySince(rawRules).map((r) => ({
                sync_id: r.sync_id,
                user_id: r.user_id || userId,
                profile_sync_id: profileSyncById.get(r.profile_id) || defaultProfileSyncId,
                category_sync_id: categorySyncById.get(r.category_id) || defaultCategorySyncId,
                title: r.title,
                type: r.type,
                amount: r.amount,
                frequency: r.frequency,
                next_due_date: r.next_due_date,
                auto_log: r.auto_log,
                active: r.active,
                updated_at: r.updated_at,
                deleted_at: r.deleted_at || null,
            })),
            transactions: filterBySince(rawTransactions).map((t) => ({
                sync_id: t.sync_id,
                user_id: t.user_id || userId,
                profile_sync_id: profileSyncById.get(t.profile_id) || defaultProfileSyncId,
                category_sync_id: categorySyncById.get(t.category_id) || defaultCategorySyncId,
                recurring_rule_sync_id: t.recurring_rule_id
                    ? ruleSyncById.get(t.recurring_rule_id) || null
                    : null,
                type: t.type,
                amount: t.amount,
                date: t.date,
                description: t.description,
                receipt_image: t.receipt_image || null,
                receipt_filename: t.receipt_filename || null,
                receipt_raw_text: t.receipt_raw_text || null,
                receipt_merchant: t.receipt_merchant || null,
                created_at: t.created_at,
                updated_at: t.updated_at,
                deleted_at: t.deleted_at || null,
            })),
            miscLists: filterBySince(rawMiscLists).map((l) => ({
                sync_id: l.sync_id,
                user_id: l.user_id || userId,
                profile_sync_id: profileSyncById.get(l.profile_id) || defaultProfileSyncId,
                category_sync_id: l.category_id ? categorySyncById.get(l.category_id) || null : null,
                title: l.title,
                target_budget: l.target_budget,
                notes: l.notes,
                status: l.status,
                created_at: l.created_at,
                updated_at: l.updated_at,
                deleted_at: l.deleted_at || null,
            })),
            miscListItems: filterBySince(rawMiscItems)
                .filter((item) => listSyncById.has(item.list_id))
                .map((item) => ({
                sync_id: item.sync_id,
                user_id: item.user_id || userId,
                list_sync_id: listSyncById.get(item.list_id),
                name: item.name,
                quantity: item.quantity,
                unit: item.unit,
                estimated_price: item.estimated_price,
                actual_price: item.actual_price,
                checked: item.checked,
                notes: item.notes,
                updated_at: item.updated_at,
                deleted_at: item.deleted_at || null,
            })),
        };
    }
    applyRemoteChangeset(changeset, targetUserId) {
        const effectiveUserId = targetUserId || changeset.userId || 'default-user';
        this.ensureSyncMetadata(effectiveUserId);
        const report = {
            applied: {
                profiles: 0,
                categories: 0,
                recurringRules: 0,
                transactions: 0,
                miscLists: 0,
                miscListItems: 0,
            },
            skippedOlderOrEqual: 0,
            conflictsResolvedLww: 0,
            serverTimestampUtc: new Date().toISOString(),
        };
        const isRemoteNewer = (remoteIso, localIso) => {
            const rMs = Date.parse(remoteIso || '1970-01-01T00:00:00.000Z');
            const lMs = Date.parse(localIso || '1970-01-01T00:00:00.000Z');
            if (Number.isNaN(rMs))
                return false;
            if (Number.isNaN(lMs))
                return true;
            return rMs > lMs;
        };
        this.db.exec('BEGIN TRANSACTION;');
        try {
            // 1. Merge Profiles
            for (const rp of changeset.profiles || []) {
                const existing = this.db
                    .prepare('SELECT id, updated_at FROM profiles WHERE sync_id = ?')
                    .get(rp.sync_id);
                if (existing) {
                    if (isRemoteNewer(rp.updated_at, existing.updated_at)) {
                        if (rp.deleted_at) {
                            this.db.prepare('DELETE FROM profiles WHERE id = ?').run(existing.id);
                        }
                        else {
                            this.db
                                .prepare(`UPDATE profiles
                   SET user_id = ?, name = ?, type = ?, color = ?, icon = ?, description = ?, updated_at = ?, deleted_at = NULL
                   WHERE id = ?`)
                                .run(effectiveUserId, rp.name, rp.type, rp.color, rp.icon, rp.description, rp.updated_at, existing.id);
                        }
                        report.applied.profiles++;
                        report.conflictsResolvedLww++;
                    }
                    else {
                        report.skippedOlderOrEqual++;
                    }
                }
                else if (!rp.deleted_at) {
                    this.db
                        .prepare(`INSERT INTO profiles (sync_id, user_id, name, type, color, icon, description, created_at, updated_at)
               VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)`)
                        .run(rp.sync_id, effectiveUserId, rp.name, rp.type, rp.color, rp.icon, rp.description, rp.created_at || rp.updated_at, rp.updated_at);
                    report.applied.profiles++;
                }
            }
            // Build profile_sync_id -> local profile.id map
            const profileIdBySync = new Map();
            const allProfiles = this.db
                .prepare('SELECT id, sync_id FROM profiles')
                .all();
            for (const p of allProfiles) {
                if (p.sync_id)
                    profileIdBySync.set(p.sync_id, p.id);
            }
            const fallbackProfileId = allProfiles[0]?.id || 1;
            // 2. Merge Categories
            for (const rc of changeset.categories || []) {
                const localProfileId = profileIdBySync.get(rc.profile_sync_id) || fallbackProfileId;
                const existing = this.db
                    .prepare('SELECT id, updated_at FROM categories WHERE sync_id = ?')
                    .get(rc.sync_id);
                if (existing) {
                    if (isRemoteNewer(rc.updated_at, existing.updated_at)) {
                        if (rc.deleted_at) {
                            this.db.prepare('DELETE FROM categories WHERE id = ?').run(existing.id);
                        }
                        else {
                            this.db
                                .prepare(`UPDATE categories
                   SET user_id = ?, profile_id = ?, name = ?, type = ?, color = ?, icon = ?, monthly_limit = ?, alert_threshold = ?, updated_at = ?, deleted_at = NULL
                   WHERE id = ?`)
                                .run(effectiveUserId, localProfileId, rc.name, rc.type, rc.color, rc.icon, rc.monthly_limit, rc.alert_threshold, rc.updated_at, existing.id);
                        }
                        report.applied.categories++;
                        report.conflictsResolvedLww++;
                    }
                    else {
                        report.skippedOlderOrEqual++;
                    }
                }
                else if (!rc.deleted_at) {
                    this.db
                        .prepare(`INSERT INTO categories (sync_id, user_id, profile_id, name, type, color, icon, monthly_limit, alert_threshold, updated_at)
               VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`)
                        .run(rc.sync_id, effectiveUserId, localProfileId, rc.name, rc.type, rc.color, rc.icon, rc.monthly_limit, rc.alert_threshold, rc.updated_at);
                    report.applied.categories++;
                }
            }
            // Build category_sync_id -> local category.id map
            const categoryIdBySync = new Map();
            const allCats = this.db
                .prepare('SELECT id, sync_id FROM categories')
                .all();
            for (const c of allCats) {
                if (c.sync_id)
                    categoryIdBySync.set(c.sync_id, c.id);
            }
            const fallbackCategoryId = allCats[0]?.id || 1;
            // 3. Merge Recurring Rules
            for (const rr of changeset.recurringRules || []) {
                const localProfileId = profileIdBySync.get(rr.profile_sync_id) || fallbackProfileId;
                const localCategoryId = categoryIdBySync.get(rr.category_sync_id) || fallbackCategoryId;
                const existing = this.db
                    .prepare('SELECT id, updated_at FROM recurring_rules WHERE sync_id = ?')
                    .get(rr.sync_id);
                if (existing) {
                    if (isRemoteNewer(rr.updated_at, existing.updated_at)) {
                        if (rr.deleted_at) {
                            this.db.prepare('DELETE FROM recurring_rules WHERE id = ?').run(existing.id);
                        }
                        else {
                            this.db
                                .prepare(`UPDATE recurring_rules
                   SET user_id = ?, profile_id = ?, category_id = ?, title = ?, type = ?, amount = ?, frequency = ?, next_due_date = ?, auto_log = ?, active = ?, updated_at = ?, deleted_at = NULL
                   WHERE id = ?`)
                                .run(effectiveUserId, localProfileId, localCategoryId, rr.title, rr.type, rr.amount, rr.frequency, rr.next_due_date, rr.auto_log, rr.active, rr.updated_at, existing.id);
                        }
                        report.applied.recurringRules++;
                        report.conflictsResolvedLww++;
                    }
                    else {
                        report.skippedOlderOrEqual++;
                    }
                }
                else if (!rr.deleted_at) {
                    this.db
                        .prepare(`INSERT INTO recurring_rules (sync_id, user_id, profile_id, category_id, title, type, amount, frequency, next_due_date, auto_log, active, updated_at)
               VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`)
                        .run(rr.sync_id, effectiveUserId, localProfileId, localCategoryId, rr.title, rr.type, rr.amount, rr.frequency, rr.next_due_date, rr.auto_log, rr.active, rr.updated_at);
                    report.applied.recurringRules++;
                }
            }
            const ruleIdBySync = new Map();
            const allRules = this.db
                .prepare('SELECT id, sync_id FROM recurring_rules')
                .all();
            for (const r of allRules) {
                if (r.sync_id)
                    ruleIdBySync.set(r.sync_id, r.id);
            }
            // 4. Merge Transactions
            for (const rt of changeset.transactions || []) {
                const localProfileId = profileIdBySync.get(rt.profile_sync_id) || fallbackProfileId;
                const localCategoryId = categoryIdBySync.get(rt.category_sync_id) || fallbackCategoryId;
                const localRuleId = rt.recurring_rule_sync_id
                    ? ruleIdBySync.get(rt.recurring_rule_sync_id) || null
                    : null;
                const existing = this.db
                    .prepare('SELECT id, updated_at FROM transactions WHERE sync_id = ?')
                    .get(rt.sync_id);
                if (existing) {
                    if (isRemoteNewer(rt.updated_at, existing.updated_at)) {
                        if (rt.deleted_at) {
                            this.db.prepare('DELETE FROM transactions WHERE id = ?').run(existing.id);
                        }
                        else {
                            this.db
                                .prepare(`UPDATE transactions
                   SET user_id = ?, profile_id = ?, category_id = ?, type = ?, amount = ?, date = ?, description = ?, recurring_rule_id = ?, receipt_image = ?, receipt_filename = ?, receipt_raw_text = ?, receipt_merchant = ?, updated_at = ?, deleted_at = NULL
                   WHERE id = ?`)
                                .run(effectiveUserId, localProfileId, localCategoryId, rt.type, rt.amount, rt.date, rt.description, localRuleId, rt.receipt_image || null, rt.receipt_filename || null, rt.receipt_raw_text || null, rt.receipt_merchant || null, rt.updated_at, existing.id);
                        }
                        report.applied.transactions++;
                        report.conflictsResolvedLww++;
                    }
                    else {
                        report.skippedOlderOrEqual++;
                    }
                }
                else if (!rt.deleted_at) {
                    this.db
                        .prepare(`INSERT INTO transactions (sync_id, user_id, profile_id, category_id, type, amount, date, description, recurring_rule_id, receipt_image, receipt_filename, receipt_raw_text, receipt_merchant, created_at, updated_at)
               VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`)
                        .run(rt.sync_id, effectiveUserId, localProfileId, localCategoryId, rt.type, rt.amount, rt.date, rt.description, localRuleId, rt.receipt_image || null, rt.receipt_filename || null, rt.receipt_raw_text || null, rt.receipt_merchant || null, rt.created_at || rt.updated_at, rt.updated_at);
                    report.applied.transactions++;
                }
            }
            // 5. Merge Misc Lists
            for (const rl of changeset.miscLists || []) {
                const localProfileId = profileIdBySync.get(rl.profile_sync_id) || fallbackProfileId;
                const localCategoryId = rl.category_sync_id
                    ? categoryIdBySync.get(rl.category_sync_id) || null
                    : null;
                const existing = this.db
                    .prepare('SELECT id, updated_at FROM misc_lists WHERE sync_id = ?')
                    .get(rl.sync_id);
                if (existing) {
                    if (isRemoteNewer(rl.updated_at, existing.updated_at)) {
                        if (rl.deleted_at) {
                            this.db.prepare('DELETE FROM misc_lists WHERE id = ?').run(existing.id);
                        }
                        else {
                            this.db
                                .prepare(`UPDATE misc_lists
                   SET user_id = ?, profile_id = ?, category_id = ?, title = ?, target_budget = ?, notes = ?, status = ?, updated_at = ?, deleted_at = NULL
                   WHERE id = ?`)
                                .run(effectiveUserId, localProfileId, localCategoryId, rl.title, rl.target_budget, rl.notes, rl.status, rl.updated_at, existing.id);
                        }
                        report.applied.miscLists++;
                        report.conflictsResolvedLww++;
                    }
                    else {
                        report.skippedOlderOrEqual++;
                    }
                }
                else if (!rl.deleted_at) {
                    this.db
                        .prepare(`INSERT INTO misc_lists (sync_id, user_id, profile_id, category_id, title, target_budget, notes, status, created_at, updated_at)
               VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`)
                        .run(rl.sync_id, effectiveUserId, localProfileId, localCategoryId, rl.title, rl.target_budget, rl.notes, rl.status, rl.created_at || rl.updated_at, rl.updated_at);
                    report.applied.miscLists++;
                }
            }
            const listIdBySync = new Map();
            const allLists = this.db
                .prepare('SELECT id, sync_id FROM misc_lists')
                .all();
            for (const l of allLists) {
                if (l.sync_id)
                    listIdBySync.set(l.sync_id, l.id);
            }
            // 6. Merge Misc List Items
            for (const ri of changeset.miscListItems || []) {
                const localListId = listIdBySync.get(ri.list_sync_id);
                if (!localListId)
                    continue;
                const existing = this.db
                    .prepare('SELECT id, updated_at FROM misc_list_items WHERE sync_id = ?')
                    .get(ri.sync_id);
                if (existing) {
                    if (isRemoteNewer(ri.updated_at, existing.updated_at)) {
                        if (ri.deleted_at) {
                            this.db.prepare('DELETE FROM misc_list_items WHERE id = ?').run(existing.id);
                        }
                        else {
                            this.db
                                .prepare(`UPDATE misc_list_items
                   SET user_id = ?, list_id = ?, name = ?, quantity = ?, unit = ?, estimated_price = ?, actual_price = ?, checked = ?, notes = ?, updated_at = ?, deleted_at = NULL
                   WHERE id = ?`)
                                .run(effectiveUserId, localListId, ri.name, ri.quantity, ri.unit, ri.estimated_price, ri.actual_price, ri.checked, ri.notes, ri.updated_at, existing.id);
                        }
                        report.applied.miscListItems++;
                        report.conflictsResolvedLww++;
                    }
                    else {
                        report.skippedOlderOrEqual++;
                    }
                }
                else if (!ri.deleted_at) {
                    this.db
                        .prepare(`INSERT INTO misc_list_items (sync_id, user_id, list_id, name, quantity, unit, estimated_price, actual_price, checked, notes, updated_at)
               VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`)
                        .run(ri.sync_id, effectiveUserId, localListId, ri.name, ri.quantity, ri.unit, ri.estimated_price, ri.actual_price, ri.checked, ri.notes, ri.updated_at);
                    report.applied.miscListItems++;
                }
            }
            this.db.exec('COMMIT;');
            return report;
        }
        catch (err) {
            this.db.exec('ROLLBACK;');
            throw err;
        }
    }
    close() {
        this.db.close();
    }
}
exports.BudgetDatabase = BudgetDatabase;
