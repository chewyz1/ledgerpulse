"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.extractDateFromReceiptText = extractDateFromReceiptText;
exports.extractMerchantFromReceiptText = extractMerchantFromReceiptText;
exports.extractAmountsFromReceiptText = extractAmountsFromReceiptText;
exports.matchCategoryForReceipt = matchCategoryForReceipt;
exports.parseReceiptText = parseReceiptText;
const MONTH_MAP = {
    jan: '01',
    january: '01',
    feb: '02',
    february: '02',
    mar: '03',
    march: '03',
    apr: '04',
    april: '04',
    may: '05',
    jun: '06',
    june: '06',
    jul: '07',
    july: '07',
    aug: '08',
    august: '08',
    sep: '09',
    sept: '09',
    september: '09',
    oct: '10',
    october: '10',
    nov: '11',
    november: '11',
    dec: '12',
    december: '12',
};
const CATEGORY_KEYWORD_RULES = [
    {
        categoryKeywords: ['grocer', 'dining', 'food', 'restaurant'],
        receiptKeywords: [
            'whole foods',
            'trader joe',
            'kroger',
            'safeway',
            'albertsons',
            'costco',
            'walmart',
            'aldi',
            'publix',
            'wegmans',
            'supermarket',
            'market',
            'grocery',
            'bakery',
            'cafe',
            'coffee',
            'starbucks',
            'chipotle',
            'bistro',
            'grill',
            'restaurant',
            'diner',
            'pizza',
            'produce',
            'organic',
            'milk',
            'bread',
            'eggs',
        ],
    },
    {
        categoryKeywords: ['transport', 'fuel', 'gas', 'auto', 'car'],
        receiptKeywords: [
            'shell',
            'chevron',
            'exxon',
            'mobil',
            'bp ',
            'texaco',
            'arco',
            'speedway',
            '76 ',
            'valero',
            'citgo',
            'unleaded',
            'gallons',
            'pump',
            'fuel',
            'gasoline',
            'uber',
            'lyft',
            'parking',
            'transit',
            'metro',
            'toll',
            'autozone',
            'jiffy lube',
        ],
    },
    {
        categoryKeywords: ['utilit', 'internet', 'electric', 'water'],
        receiptKeywords: [
            'electric',
            'power',
            'energy',
            'water',
            'sewer',
            'utility',
            'comcast',
            'xfinity',
            'verizon',
            'at&t',
            't-mobile',
            'spectrum',
            'fiber',
            'internet',
            'kilowatt',
            'kwh',
            'coned',
            'pg&e',
        ],
    },
    {
        categoryKeywords: ['health', 'wellness', 'medical', 'pharmacy'],
        receiptKeywords: [
            'cvs',
            'walgreens',
            'rite aid',
            'pharmacy',
            'rx ',
            'prescription',
            'clinic',
            'dental',
            'vision',
            'optometry',
            'hospital',
            'medical',
            'doctor',
            'copay',
            'fitness',
            'gym',
            'vitamin',
        ],
    },
    {
        categoryKeywords: ['subscription', 'media', 'stream', 'software'],
        receiptKeywords: [
            'netflix',
            'spotify',
            'apple.com/bill',
            'icloud',
            'google storage',
            'youtube',
            'hulu',
            'disney+',
            'openai',
            'github',
            'adobe',
            'dropbox',
            'membership',
            'subscription',
        ],
    },
    {
        categoryKeywords: ['housing', 'rent', 'home', 'mortgage'],
        receiptKeywords: [
            'home depot',
            'lowe',
            'ikea',
            'ace hardware',
            'apartment',
            'property management',
            'rent',
            'hoa ',
            'maintenance',
            'plumbing',
        ],
    },
    {
        categoryKeywords: ['entertainment', 'shopping', 'retail'],
        receiptKeywords: [
            'target',
            'amazon',
            'best buy',
            'apple store',
            'nordstrom',
            'macy',
            'cinema',
            'AMC ',
            'regal',
            'theater',
            'ticketmaster',
            'bookstore',
            'barnes',
            'apparel',
        ],
    },
];
function extractDateFromReceiptText(rawText) {
    // 1. ISO format YYYY-MM-DD or YYYY/MM/DD
    const isoMatch = rawText.match(/\b(20\d{2})[-/.](0[1-9]|1[0-2])[-/.](0[1-9]|[12]\d|3[01])\b/);
    if (isoMatch) {
        return `${isoMatch[1]}-${isoMatch[2]}-${isoMatch[3]}`;
    }
    // 2. US format MM/DD/YYYY or MM-DD-YYYY or MM/DD/YY
    const usMatch = rawText.match(/\b(0?[1-9]|1[0-2])[/-](0?[1-9]|[12]\d|3[01])[/-](20\d{2}|\d{2})\b/);
    if (usMatch) {
        const mm = usMatch[1].padStart(2, '0');
        const dd = usMatch[2].padStart(2, '0');
        const yyyy = usMatch[3].length === 2 ? `20${usMatch[3]}` : usMatch[3];
        return `${yyyy}-${mm}-${dd}`;
    }
    // 3. Named month format: Oct 31, 2026 or October 31 2026
    const namedMatch = rawText.match(/\b(Jan(?:uary)?|Feb(?:ruary)?|Mar(?:ch)?|Apr(?:il)?|May|Jun(?:e)?|Jul(?:y)?|Aug(?:ust)?|Sep(?:t(?:ember)?)?|Oct(?:ober)?|Nov(?:ember)?|Dec(?:ember)?)\.?\s+(\d{1,2})(?:st|nd|rd|th)?,?\s+(20\d{2})\b/i);
    if (namedMatch) {
        const monthKey = namedMatch[1].toLowerCase();
        const mm = MONTH_MAP[monthKey] || '01';
        const dd = namedMatch[2].padStart(2, '0');
        const yyyy = namedMatch[3];
        return `${yyyy}-${mm}-${dd}`;
    }
    return null;
}
function extractMerchantFromReceiptText(rawText) {
    const lines = rawText
        .split(/\r?\n/)
        .map((l) => l.trim())
        .filter((l) => l.length >= 2);
    const ignorePatterns = [
        /^receipt\b/i,
        /^tax invoice/i,
        /^customer copy/i,
        /^merchant copy/i,
        /^welcome to\b/i,
        /^thank you/i,
        /^\d{1,5}\s+[a-z0-9.\s]+(?:st|street|ave|avenue|rd|road|blvd|dr|drive|ln|lane|way|pkwy)\b/i,
        /^\(?\d{3}\)?[-.\s]?\d{3}[-.\s]?\d{4}$/,
        /^tel[:\s]/i,
        /^phone[:\s]/i,
        /^store\s*#?\d+/i,
        /^cashier[:\s]/i,
        /^date[:\s]/i,
        /^\d{1,2}[/-]\d{1,2}[/-]\d{2,4}/,
        /^www\./i,
        /^https?:\/\//i,
    ];
    for (const line of lines.slice(0, 8)) {
        const cleaned = line.replace(/^welcome to\s+/i, '').replace(/[*#=_~]+/g, '').trim();
        if (!cleaned || cleaned.length < 3)
            continue;
        // Skip lines that are mostly digits/symbols
        const alphaCount = (cleaned.match(/[a-zA-Z]/g) || []).length;
        if (alphaCount < 3)
            continue;
        if (ignorePatterns.some((pat) => pat.test(cleaned)))
            continue;
        // Skip if it looks like an item line with a price at the end
        if (/\$\s*\d+\.\d{2}$/.test(cleaned) && !/market|foods|store|cafe|coffee|gas|shell/i.test(cleaned)) {
            continue;
        }
        return cleaned
            .split(/\s+/)
            .map((w) => (w.length > 2 ? w[0].toUpperCase() + w.slice(1).toLowerCase() : w.toUpperCase()))
            .join(' ');
    }
    return 'Scanned Receipt Expense';
}
function extractAmountsFromReceiptText(rawText) {
    const lines = rawText.split(/\r?\n/).map((l) => l.trim());
    let subtotal = null;
    let tax = null;
    const totalCandidates = [];
    const allCurrencyAmounts = [];
    const amountRegex = /\$?\s*(\d{1,6}(?:,\d{3})*\.\d{2})\b/g;
    for (const line of lines) {
        const lower = line.toLowerCase();
        const matches = [...line.matchAll(amountRegex)].map((m) => parseFloat(m[1].replace(/,/g, '')));
        if (matches.length === 0)
            continue;
        const lastVal = matches[matches.length - 1];
        for (const v of matches) {
            if (v > 0 && v < 100000)
                allCurrencyAmounts.push(v);
        }
        if (/\bsub\s*-?\s*total\b/i.test(lower)) {
            subtotal = lastVal;
            continue;
        }
        if (/\b(?:sales\s+)?tax\b|\bvat\b|\bgst\b|\bhst\b/i.test(lower)) {
            tax = lastVal;
            continue;
        }
        // Ignore change due / cash tendered / savings lines when looking for total
        if (/\b(?:change|tender|cash|saved|savings|discount)\b/i.test(lower)) {
            continue;
        }
        if (/\b(?:grand\s+total|total\s+due|amount\s+due|balance\s+due|total\s+amount|total)\b/i.test(lower)) {
            totalCandidates.push(lastVal);
        }
    }
    let total = null;
    if (totalCandidates.length > 0) {
        // Usually the final "TOTAL" line on a receipt is the true grand total
        total = Math.max(...totalCandidates);
    }
    else if (subtotal !== null && tax !== null) {
        total = Number((subtotal + tax).toFixed(2));
    }
    else if (allCurrencyAmounts.length > 0) {
        total = Math.max(...allCurrencyAmounts);
    }
    return { total, subtotal, tax };
}
function matchCategoryForReceipt(rawText, merchant, categories) {
    const expenseCategories = categories.filter((c) => c.type === 'expense');
    if (expenseCategories.length === 0)
        return null;
    const combined = `${merchant} ${rawText}`.toLowerCase();
    // Direct category name match first
    for (const cat of expenseCategories) {
        const words = cat.name
            .toLowerCase()
            .split(/[^a-z0-9]+/)
            .filter((w) => w.length >= 4);
        if (words.some((w) => combined.includes(w))) {
            return cat;
        }
    }
    // Keyword rule scoring
    let bestCategory = null;
    let bestScore = 0;
    for (const rule of CATEGORY_KEYWORD_RULES) {
        let score = 0;
        for (const kw of rule.receiptKeywords) {
            if (combined.includes(kw.toLowerCase())) {
                score += merchant.toLowerCase().includes(kw.toLowerCase()) ? 3 : 1;
            }
        }
        if (score > bestScore) {
            const targetCat = expenseCategories.find((cat) => rule.categoryKeywords.some((ck) => cat.name.toLowerCase().includes(ck)));
            if (targetCat) {
                bestScore = score;
                bestCategory = targetCat;
            }
        }
    }
    return bestCategory || expenseCategories[0];
}
function parseReceiptText(rawText, categories) {
    const merchant = extractMerchantFromReceiptText(rawText);
    const date = extractDateFromReceiptText(rawText);
    const { total, subtotal, tax } = extractAmountsFromReceiptText(rawText);
    const matchedCat = matchCategoryForReceipt(rawText, merchant, categories);
    let confidence = 'low';
    if (total !== null && date !== null && merchant !== 'Scanned Receipt Expense') {
        confidence = 'high';
    }
    else if (total !== null) {
        confidence = 'medium';
    }
    return {
        merchant,
        amount: total,
        subtotal,
        tax,
        date,
        suggestedCategoryId: matchedCat?.id ?? null,
        suggestedCategoryName: matchedCat?.name ?? null,
        confidence,
        rawText: rawText.trim(),
    };
}
