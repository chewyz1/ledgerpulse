"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const node_test_1 = __importDefault(require("node:test"));
const strict_1 = __importDefault(require("node:assert/strict"));
const db_1 = require("./db");
(0, node_test_1.default)('BudgetDatabase initializes default categories, transactions, and recurring rules', () => {
    const db = new db_1.BudgetDatabase(':memory:');
    const categories = db.getCategories();
    strict_1.default.ok(categories.length >= 9, 'Should seed default categories');
    const rules = db.getRecurringRules();
    strict_1.default.ok(rules.length >= 4, 'Should seed default recurring rules');
    db.close();
});
(0, node_test_1.default)('BudgetDatabase detects budget warning and exceeded thresholds', () => {
    const db = new db_1.BudgetDatabase(':memory:');
    const testCat = db.createCategory({
        name: 'Coffee & Snacks',
        type: 'expense',
        color: '#f59e0b',
        icon: 'coffee',
        monthly_limit: 100,
        alert_threshold: 0.8,
    });
    db.createTransaction({
        category_id: testCat.id,
        type: 'expense',
        amount: 85,
        date: '2026-10-15',
        description: 'Specialty coffee beans',
    });
    let summary = db.getDashboardSummary('2026-10');
    const coffeeBudget = summary.categoryBudgets.find((b) => b.category.id === testCat.id);
    strict_1.default.ok(coffeeBudget);
    strict_1.default.equal(coffeeBudget.status, 'warning');
    strict_1.default.equal(coffeeBudget.spent, 85);
    db.createTransaction({
        category_id: testCat.id,
        type: 'expense',
        amount: 25,
        date: '2026-10-20',
        description: 'Pastries & espresso',
    });
    summary = db.getDashboardSummary('2026-10');
    const updatedBudget = summary.categoryBudgets.find((b) => b.category.id === testCat.id);
    strict_1.default.ok(updatedBudget);
    strict_1.default.equal(updatedBudget.status, 'exceeded');
    strict_1.default.equal(updatedBudget.spent, 110);
    db.close();
});
(0, node_test_1.default)('Recurring rules trigger and advance next_due_date accurately', () => {
    const db = new db_1.BudgetDatabase(':memory:');
    const categories = db.getCategories();
    const expenseCat = categories.find((c) => c.type === 'expense');
    const rule = db.createRecurringRule({
        title: 'Cloud Server Hosting',
        category_id: expenseCat.id,
        type: 'expense',
        amount: 40,
        frequency: 'monthly',
        next_due_date: '2026-10-05',
        auto_log: true,
    });
    const { transaction, updatedRule } = db.triggerRecurringRuleNow(rule.id);
    strict_1.default.equal(transaction.amount, 40);
    strict_1.default.equal(updatedRule.next_due_date, '2026-11-05');
    strict_1.default.equal((0, db_1.advanceDateByFrequency)('2026-10-01', 'weekly'), '2026-10-08');
    db.close();
});
(0, node_test_1.default)('Receipt parser extracts merchant, date, subtotal, tax, total, and category', () => {
    const db = new db_1.BudgetDatabase(':memory:');
    const sampleReceipt = [
        'WHOLE FOODS MARKET',
        '450 Market St',
        'Date: 2026-10-19  Time: 17:42',
        'ORGANIC HONEYCRISP APPLES  $6.49',
        'WILD ALASKAN SALMON        $18.99',
        'SUBTOTAL                   $25.48',
        'SALES TAX                   $2.10',
        'TOTAL                      $27.58',
    ].join('\n');
    const parsed = db.parseReceipt(sampleReceipt);
    strict_1.default.equal(parsed.merchant, 'Whole Foods Market');
    strict_1.default.equal(parsed.date, '2026-10-19');
    strict_1.default.equal(parsed.subtotal, 25.48);
    strict_1.default.equal(parsed.tax, 2.1);
    strict_1.default.equal(parsed.amount, 27.58);
    strict_1.default.equal(parsed.suggestedCategoryName, 'Groceries & Dining');
    strict_1.default.equal(parsed.confidence, 'high');
    const savedTx = db.createTransaction({
        category_id: parsed.suggestedCategoryId,
        type: 'expense',
        amount: parsed.amount,
        date: parsed.date,
        description: parsed.merchant,
        receipt_image: 'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mNk+A8AAQUBAScY42YAAAAASUVORK5CYII=',
        receipt_filename: 'whole-foods-oct19.png',
        receipt_raw_text: sampleReceipt,
        receipt_merchant: parsed.merchant,
    });
    strict_1.default.equal(savedTx.receipt_filename, 'whole-foods-oct19.png');
    strict_1.default.ok(savedTx.receipt_image?.startsWith('data:image/png;base64,'));
    // Search by item inside the scanned receipt OCR text
    const foundByOcr = db.getTransactions({ search: 'honeycrisp' });
    strict_1.default.equal(foundByOcr.length, 1);
    strict_1.default.equal(foundByOcr[0].id, savedTx.id);
    db.close();
});
(0, node_test_1.default)('Multi-profile isolation and inter-profile allowance transfer work accurately', () => {
    const db = new db_1.BudgetDatabase(':memory:');
    const profiles = db.getProfiles();
    strict_1.default.equal(profiles.length, 3);
    strict_1.default.equal(profiles[0].type, 'personal');
    strict_1.default.equal(profiles[1].type, 'business');
    strict_1.default.equal(profiles[2].type, 'child');
    // Create a new Child profile with template categories
    const mayaProfile = db.createProfile({
        name: "Maya's Allowance",
        type: 'child',
        color: '#ec4899',
        description: 'Allowance & school savings',
        seedTemplate: true,
    });
    const mayaCats = db.getCategories(mayaProfile.id);
    strict_1.default.ok(mayaCats.length >= 5, 'Child template should seed child categories');
    // Transfer $25 allowance from Personal Budget (profile 1) to Maya's Allowance
    const transferRes = db.transferBetweenProfiles({
        fromProfileId: 1,
        toProfileId: mayaProfile.id,
        amount: 25,
        date: '2026-10-25',
        description: 'Weekly Allowance',
    });
    strict_1.default.equal(transferRes.outTransaction.profile_id, 1);
    strict_1.default.equal(transferRes.outTransaction.type, 'expense');
    strict_1.default.equal(transferRes.inTransaction.profile_id, mayaProfile.id);
    strict_1.default.equal(transferRes.inTransaction.type, 'income');
    const mayaSummary = db.getDashboardSummary('2026-10', mayaProfile.id);
    strict_1.default.equal(mayaSummary.totalIncome, 25);
    strict_1.default.equal(mayaSummary.totalExpense, 0);
    db.close();
});
(0, node_test_1.default)('Full backup export/import, CSV export, and demo reset work across devices', () => {
    const db1 = new db_1.BudgetDatabase(':memory:');
    db1.createProfile({
        name: 'Test Device Profile',
        type: 'business',
        color: '#6366f1',
        seedTemplate: true,
    });
    const backup = db1.exportBackupBundle();
    strict_1.default.equal(backup.app, 'LedgerPulse');
    strict_1.default.equal(backup.profiles.length, 4);
    const csv = db1.exportTransactionsCsv();
    strict_1.default.ok(csv.includes('ID,Profile,Profile Type,Date,Entry Type,Category,Amount'));
    strict_1.default.ok(csv.split('\n').length > 5);
    // Import into a second fresh database (simulating another test device)
    const db2 = new db_1.BudgetDatabase(':memory:');
    const stats = db2.importBackupBundle(backup);
    strict_1.default.equal(stats.profiles, 4);
    strict_1.default.equal(db2.getProfiles().length, 4);
    // Reset back to default 3 demo profiles
    db2.resetDemoData();
    strict_1.default.equal(db2.getProfiles().length, 3);
    db1.close();
    db2.close();
});
(0, node_test_1.default)('Misc ledgers and shopping lists calculate totals and convert to transactions', () => {
    const db = new db_1.BudgetDatabase(':memory:');
    const cats = db.getCategories(1);
    const groceryCat = cats.find((c) => c.name.includes('Groceries')) || cats[0];
    const list = db.createMiscList({
        profile_id: 1,
        title: 'Weekend BBQ Shopping List',
        category_id: groceryCat.id,
        target_budget: 75,
        notes: 'Backyard cookout supplies',
    });
    const item1 = db.addMiscListItem({
        list_id: list.id,
        name: 'Grass-Fed Burger Patties',
        quantity: 2,
        unit: 'pack',
        estimated_price: 12.5,
        actual_price: 11.0,
    });
    const item2 = db.addMiscListItem({
        list_id: list.id,
        name: 'Brioche Buns & Condiments',
        quantity: 1,
        unit: 'set',
        estimated_price: 8.5,
    });
    // Check off item1 as in-cart
    db.updateMiscListItem({ id: item1.id, checked: true });
    strict_1.default.ok(item2.id > 0);
    const lists = db.getMiscLists(1);
    const updated = lists.find((l) => l.id === list.id);
    strict_1.default.equal(updated.plannedTotal, 33.5); // 2*12.5 + 8.5
    strict_1.default.equal(updated.checkedTotal, 22.0); // 2*11.0
    strict_1.default.equal(updated.effectiveTotal, 30.5); // 2*11.0 + 8.5
    // Convert checked items into an expense transaction and clear checked items
    const checkout = db.checkoutMiscListToTransaction({
        list_id: list.id,
        mode: 'checked_only',
        category_id: groceryCat.id,
        date: '2026-10-26',
        description: 'BBQ Meat Run',
        remove_checked_items: true,
    });
    strict_1.default.equal(checkout.transaction.amount, 22.0);
    strict_1.default.equal(checkout.updatedList.items.length, 1);
    strict_1.default.equal(checkout.updatedList.items[0].name, 'Brioche Buns & Condiments');
    db.close();
});
