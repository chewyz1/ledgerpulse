import http from 'node:http';
import fs from 'node:fs';
import path from 'node:path';
import os from 'node:os';
import { fileURLToPath } from 'node:url';
import { createRequire } from 'node:module';

const require = createRequire(import.meta.url);
const __dirname = path.dirname(fileURLToPath(import.meta.url));
const rootDir = path.resolve(__dirname, '..');
const distDir = path.join(rootDir, 'dist');

const { BudgetDatabase } = require(path.join(rootDir, 'dist-electron/db.js'));
const dbPath = path.join(os.homedir(), '.config', 'budget-tracker', 'budget-tracker.sqlite');
const db = new BudgetDatabase(dbPath);
db.processDueRecurringRules();

const MIME_TYPES = {
  '.html': 'text/html; charset=utf-8',
  '.js': 'application/javascript; charset=utf-8',
  '.css': 'text/css; charset=utf-8',
  '.json': 'application/json; charset=utf-8',
  '.svg': 'image/svg+xml',
  '.png': 'image/png',
};

function readJsonBody(req) {
  return new Promise((resolve, reject) => {
    let data = '';
    req.on('data', (chunk) => {
      data += chunk;
    });
    req.on('end', () => {
      if (!data) return resolve({});
      try {
        resolve(JSON.parse(data));
      } catch (e) {
        reject(e);
      }
    });
    req.on('error', reject);
  });
}

function sendJson(res, status, payload) {
  res.writeHead(status, { 'Content-Type': 'application/json; charset=utf-8' });
  res.end(JSON.stringify(payload));
}

const server = http.createServer(async (req, res) => {
  try {
    const url = new URL(req.url || '/', 'http://localhost:5173');

    if (url.pathname === '/api/rpc' && req.method === 'POST') {
      const { method, args = [] } = await readJsonBody(req);
      if (typeof db[method] !== 'function') {
        return sendJson(res, 400, { error: `Unknown method: ${method}` });
      }
      const result = db[method](...args);
      return sendJson(res, 200, { result });
    }

    let filePath = path.join(distDir, url.pathname === '/' ? 'index.html' : url.pathname);
    if (!filePath.startsWith(distDir) || !fs.existsSync(filePath) || fs.statSync(filePath).isDirectory()) {
      filePath = path.join(distDir, 'index.html');
    }

    const ext = path.extname(filePath);
    const contentType = MIME_TYPES[ext] || 'application/octet-stream';
    res.writeHead(200, { 'Content-Type': contentType });
    fs.createReadStream(filePath).pipe(res);
  } catch (err) {
    sendJson(res, 500, { error: err instanceof Error ? err.message : String(err) });
  }
});

const PORT = Number(process.env.PORT) || 5173;
server.listen(PORT, '127.0.0.1', () => {
  console.log(`✔ LedgerPulse server listening at http://localhost:${PORT}`);
  console.log(`✔ SQLite Database: ${dbPath}`);
});

