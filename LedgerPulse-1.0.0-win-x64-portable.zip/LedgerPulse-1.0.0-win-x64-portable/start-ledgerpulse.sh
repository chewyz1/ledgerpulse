#!/usr/bin/env bash
set -e
DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$DIR"

PORT=${PORT:-5173}
echo "Starting LedgerPulse SQLite Desktop Engine on http://127.0.0.1:$PORT ..."
node scripts/dev-server.mjs &
SERVER_PID=$!
trap "kill $SERVER_PID 2>/dev/null || true" EXIT

sleep 1
URL="http://127.0.0.1:$PORT"

if command -v google-chrome >/dev/null 2>&1; then
  google-chrome --app="$URL" >/dev/null 2>&1 || true
elif command -v chromium >/dev/null 2>&1; then
  chromium --app="$URL" >/dev/null 2>&1 || true
elif command -v xdg-open >/dev/null 2>&1; then
  xdg-open "$URL" >/dev/null 2>&1 || true
fi

echo "LedgerPulse is running at $URL (Press Ctrl+C to stop)"
wait $SERVER_PID
